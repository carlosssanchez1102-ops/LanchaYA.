# LanchaYa Iquitos

Aplicación web full stack para consultar y publicar **salidas fluviales desde Iquitos** (lanchas, rápidos y
deslizadores): destino, puerto, fecha y hora, duración, precio y cupos. Las empresas registran sus salidas y los
pasajeros las filtran y reservan cupos (sin pago).

- **Backend:** Node.js + Express 4 (API REST), persistencia en archivos JSON.
- **Frontend:** React 18 + Vite, `react-router-dom`, `recharts`, `fetch`.

## Integrantes

- _(completar: nombres y apellidos)_

## Requisitos

- Node.js 20 o superior y npm.

## Instalación y ejecución

Abre **dos terminales**.

### 1. Backend (puerto 3000)

```bash
cd backend
npm install
cp .env.example .env      # opcional: los valores por defecto ya funcionan
npm run dev               # modo desarrollo con nodemon (o: npm start)
```

Comprueba que responde: <http://localhost:3000/api/salidas>

### 2. Frontend (puerto 5173)

```bash
cd frontend
npm install
cp .env.example .env      # opcional: VITE_API_URL=http://localhost:3000/api
npm run dev
```

Abre <http://localhost:5173>.

### Variables de entorno

| Dónde    | Variable       | Por defecto                 | Uso                                           |
| -------- | -------------- | --------------------------- | --------------------------------------------- |
| backend  | `PORT`         | `3000`                      | Puerto del servidor                           |
| backend  | `DATA_PATH`    | `./src/data`                | Carpeta con `salidas.json`, `empresas.json`, `reservas.json` |
| frontend | `VITE_API_URL` | `http://localhost:3000/api` | URL base de la API                            |

> Para volver a los datos iniciales, restaura los tres JSON de `backend/src/data/` (por ejemplo con `git checkout`).

## Estructura

```
lanchaya/
├── backend/
│   ├── src/
│   │   ├── index.js                  # arranque (cors, json, logger, rutas, errores)
│   │   ├── db.js                     # lectura/escritura de los JSON
│   │   ├── validators.js             # validaciones de salidas, empresas y reservas
│   │   ├── routes/                   # salidas, destinos, empresas, reservas, estadisticas
│   │   ├── controllers/              # lógica de cada recurso
│   │   ├── middleware/               # logger y manejo de errores
│   │   ├── utils/                    # errores HTTP y fechas (hora de Iquitos)
│   │   └── data/                     # salidas.json (14), empresas.json (6), reservas.json (4)
│   ├── LanchaYa.postman_collection.json
│   └── package.json
├── frontend/
│   └── src/
│       ├── App.jsx, main.jsx, index.css
│       ├── pages/                    # Salidas, formulario, detalle, Empresas, Panel, Mi reserva
│       ├── components/               # SalidaCard, Filtros, SalidaForm, ReservaForm, EmpresaForm, CuposBar...
│       ├── services/api.js           # todas las llamadas HTTP
│       ├── context/, hooks/, utils/
└── README.md
```

## API REST

Todas las rutas empiezan con `/api`. Los errores siempre tienen la forma `{ "error": true, "mensaje": "..." }`.

### Salidas

| Método | Ruta                       | Descripción                                   | Respuesta        |
| ------ | -------------------------- | --------------------------------------------- | ---------------- |
| GET    | `/salidas`                 | Lista con filtros, orden y paginación         | 200 + arreglo    |
| GET    | `/salidas/:id`             | Detalle                                       | 200 / 404        |
| POST   | `/salidas`                 | Registra una salida                           | 201 / 400        |
| PUT    | `/salidas/:id`             | Actualiza una salida                          | 200 / 400 / 404  |
| DELETE | `/salidas/:id`             | Elimina la salida y sus reservas              | 204 / 404        |
| PATCH  | `/salidas/:id/estado`      | `programada`, `abordando`, `zarpó`, `cancelada` | 200 / 400 / 404 |
| GET    | `/destinos`                | Destinos sin repetir                          | 200 + arreglo    |

**Parámetros de `GET /salidas`:** `destino`, `fecha` (`YYYY-MM-DD`), `tipo`, `q` (texto en empresa o embarcación),
`precioMin`, `precioMax`, `hoy=true`, `proximas48=true`, `orden=fecha|precio|duracion`, `dir=asc|desc`,
`page`, `limit`. Sin `orden`, se ordena por fecha más próxima. La respuesta es siempre un arreglo; con paginación el
total viaja en los encabezados `X-Total-Count` y `X-Total-Pages`.

**Validaciones (400 con mensaje claro):** `empresa` (o `empresaId`), `destino`, `puerto` y `fechaHora` obligatorios;
`precio` > 0; `tipo` ∈ `lancha | rapido | deslizador`; `fechaHora` no puede estar en el pasado al registrar.
Además: `duracionHoras` > 0 y cupos enteros ≥ 1.

### Empresas

| Método | Ruta                      | Notas                                                         |
| ------ | ------------------------- | ------------------------------------------------------------- |
| GET    | `/empresas`, `/empresas/:id` | 200 / 404                                                  |
| POST   | `/empresas`               | `razonSocial`, `ruc` (11 dígitos), `telefono`, `puertoBase`. 409 si el RUC ya existe |
| PUT    | `/empresas/:id`           | Actualiza (y sincroniza el nombre en sus salidas)             |
| DELETE | `/empresas/:id`           | **409** si tiene salidas futuras                              |
| GET    | `/empresas/:id/salidas`   | Salidas de la empresa                                         |

### Reservas (sin pago)

| Método | Ruta                          | Notas                                                                 |
| ------ | ----------------------------- | --------------------------------------------------------------------- |
| POST   | `/salidas/:id/reservas`       | `nombre`, `dni` (8 dígitos), `telefono`, `cantidad`. Descuenta cupos y devuelve un código `LY-XXXXX`. **409** si no alcanzan los cupos o la salida `zarpó`/`cancelada` |
| GET    | `/salidas/:id/reservas`       | Reservas de la salida                                                 |
| GET    | `/reservas/:codigo`           | Consulta por código (incluye datos de la salida y el total)           |
| DELETE | `/reservas/:id`               | Cancela y devuelve los cupos a la salida                              |

### Estadísticas

`GET /api/estadisticas` → totales, salidas y precio promedio por destino, salidas por tipo y por estado, cupos reservados.

## Funcionalidades del frontend

- **Salidas:** tarjetas ordenadas por fecha más próxima, con estado (etiqueta de color), cupos y precio.
- **Filtros:** destino (cargado desde `/api/destinos`), fecha, tipo, búsqueda por texto, rango de precio, "solo hoy" y
  "próximas 48 horas", orden por fecha/precio/duración, botón **Limpiar filtros**. Los últimos filtros se guardan en
  `localStorage`. Paginación con botones Anterior/Siguiente.
- **Formulario** de registro y edición con validación antes de enviar, y validación del servidor mostrada en pantalla.
- **Eliminar** con confirmación en modal; avisos (toasts) de éxito y error.
- **Detalle** `/salidas/:id`: cuenta regresiva, barra de cupos (verde > 50 %, amarillo 20–50 %, rojo < 20 % de cupos
  libres), reserva de cupos, cambio de estado y botón **Compartir por WhatsApp**.
- **Empresas:** listado, alta/edición/baja y ver las salidas de cada una.
- **Mi reserva** `/reserva/:codigo`: consulta y cancelación con el código.
- **Panel:** tarjetas de totales y gráficos de barras (Recharts).
- Estados de carga, lista vacía y error de conexión; diseño responsive (pensado para el celular) y modo oscuro.

## Decisiones de diseño

- **Cupos:** en `POST`/`PUT /salidas` el campo `cupos` (o `capacidad`) es el **total de asientos**. La salida guarda
  `capacidad` (total) y `cupos` (disponibles); las reservas descuentan de `cupos`. Al editar no se puede bajar la
  capacidad por debajo de lo ya reservado.
- **Zona horaria:** `fechaHora` se guarda como `YYYY-MM-DDTHH:mm` y siempre se interpreta como hora de Iquitos
  (UTC-5), sin importar la zona del servidor o del navegador.
- **Privacidad:** la interfaz no lista nombres ni DNI de los pasajeros; cada pasajero consulta o cancela con su código.
  El endpoint `GET /salidas/:id/reservas` existe porque lo pide el alcance, pero no tiene autenticación (el login queda
  fuera de alcance).
- **Datos iniciales:** las fechas de `salidas.json` están en noviembre de 2026. Si las pruebas se hacen después, las
  salidas ya estarán en el pasado: crea salidas nuevas desde el formulario o ajusta las fechas del JSON.

## Probar la API con Postman / Thunder Client

Importa `backend/LanchaYa.postman_collection.json` (variable `baseUrl = http://localhost:3000`). Incluye casos de
éxito y de error (400, 404, 409) para todos los endpoints.
