// Las fechas del sistema se guardan como "YYYY-MM-DDTHH:mm" SIN zona horaria
// y se interpretan siempre como hora de Iquitos (UTC-5), sin importar dónde
// corra el servidor.
const OFFSET_LIMA = '-05:00';
const MS_LIMA = 5 * 60 * 60 * 1000;
const RE_FECHA_HORA = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})(?::(\d{2}))?$/;
const RE_FECHA = /^(\d{4})-(\d{2})-(\d{2})$/;

function diaExiste(y, mo, d) {
  if (mo < 1 || mo > 12 || d < 1) return false;
  const f = new Date(Date.UTC(y, mo - 1, d));
  return f.getUTCMonth() === mo - 1 && f.getUTCDate() === d;
}

function esFechaHoraValida(valor) {
  if (typeof valor !== 'string') return false;
  const m = RE_FECHA_HORA.exec(valor);
  if (!m) return false;
  const [y, mo, d, h, mi] = [m[1], m[2], m[3], m[4], m[5]].map(Number);
  const s = Number(m[6] || 0);
  return diaExiste(y, mo, d) && h <= 23 && mi <= 59 && s <= 59;
}

function esFechaValida(valor) {
  if (typeof valor !== 'string') return false;
  const m = RE_FECHA.exec(valor);
  return !!m && diaExiste(Number(m[1]), Number(m[2]), Number(m[3]));
}

// Milisegundos desde epoch de una fechaHora de Iquitos
function aEpoch(fechaHora) {
  const base = fechaHora.length === 16 ? `${fechaHora}:00` : fechaHora;
  return Date.parse(`${base}${OFFSET_LIMA}`);
}

// "YYYY-MM-DD" de hoy en Iquitos
function hoyLima() {
  return new Date(Date.now() - MS_LIMA).toISOString().slice(0, 10);
}

module.exports = { esFechaHoraValida, esFechaValida, aEpoch, hoyLima };
