// Error con código HTTP; el middleware de errores lo convierte en
// { "error": true, "mensaje": "..." }
class HttpError extends Error {
  constructor(status, mensaje, errores) {
    super(mensaje);
    this.status = status;
    this.errores = errores;
  }
}

const badRequest = (mensaje, errores) => new HttpError(400, mensaje, errores);
const notFound = (mensaje) => new HttpError(404, mensaje);
const conflict = (mensaje) => new HttpError(409, mensaje);

// Convierte la lista de errores de un validador en un 400 con mensaje claro.
const validacion = (errores) => new HttpError(400, errores.join('. ') + '.', errores);

function parseId(valor) {
  const id = Number(valor);
  if (!Number.isInteger(id) || id < 1) throw badRequest('El id debe ser un número entero positivo');
  return id;
}

module.exports = { HttpError, badRequest, notFound, conflict, validacion, parseId };
