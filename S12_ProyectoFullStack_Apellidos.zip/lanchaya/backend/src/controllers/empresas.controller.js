const db = require('../db');
const { validateEmpresa } = require('../validators');
const { notFound, conflict, validacion, parseId } = require('../utils/errors');
const { aEpoch } = require('../utils/fechas');

function buscar(id) {
  const empresa = db.read('empresas').find((e) => e.id === id);
  if (!empresa) throw notFound(`No existe la empresa con id ${id}`);
  return empresa;
}

// GET /api/empresas
exports.listar = (req, res) => {
  const empresas = db.read('empresas').sort((a, b) => a.razonSocial.localeCompare(b.razonSocial, 'es'));
  res.status(200).json(empresas);
};

// GET /api/empresas/:id
exports.obtener = (req, res) => {
  res.status(200).json(buscar(parseId(req.params.id)));
};

// POST /api/empresas
exports.crear = (req, res) => {
  const { errores, valor } = validateEmpresa(req.body);
  if (errores.length) throw validacion(errores);

  const empresas = db.read('empresas');
  if (empresas.some((e) => e.ruc === valor.ruc)) throw conflict('Ya existe una empresa registrada con ese RUC');

  const nueva = { id: db.nextId(empresas), ...valor };
  empresas.push(nueva);
  db.write('empresas', empresas);
  res.status(201).json(nueva);
};

// PUT /api/empresas/:id
exports.actualizar = (req, res) => {
  const id = parseId(req.params.id);
  const empresas = db.read('empresas');
  const indice = empresas.findIndex((e) => e.id === id);
  if (indice === -1) throw notFound(`No existe la empresa con id ${id}`);

  const { errores, valor } = validateEmpresa(req.body);
  if (errores.length) throw validacion(errores);
  if (empresas.some((e) => e.ruc === valor.ruc && e.id !== id)) {
    throw conflict('Ya existe otra empresa registrada con ese RUC');
  }

  empresas[indice] = { id, ...valor };
  db.write('empresas', empresas);

  // Mantiene sincronizado el nombre que se muestra en las salidas de la empresa
  const salidas = db.read('salidas');
  let cambio = false;
  for (const s of salidas) {
    if (s.empresaId === id && s.empresa !== valor.razonSocial) {
      s.empresa = valor.razonSocial;
      cambio = true;
    }
  }
  if (cambio) db.write('salidas', salidas);

  res.status(200).json(empresas[indice]);
};

// DELETE /api/empresas/:id  (409 si tiene salidas futuras)
exports.eliminar = (req, res) => {
  const id = parseId(req.params.id);
  const empresas = db.read('empresas');
  if (!empresas.some((e) => e.id === id)) throw notFound(`No existe la empresa con id ${id}`);

  const ahora = Date.now();
  const futuras = db.read('salidas').filter((s) => s.empresaId === id && aEpoch(s.fechaHora) >= ahora);
  if (futuras.length) {
    throw conflict(
      `No se puede eliminar la empresa: tiene ${futuras.length} salida(s) futura(s). Elimínalas o cancélalas primero.`
    );
  }

  db.write('empresas', empresas.filter((e) => e.id !== id));
  res.status(204).send();
};

// GET /api/empresas/:id/salidas
exports.salidas = (req, res) => {
  const id = parseId(req.params.id);
  buscar(id);
  const salidas = db
    .read('salidas')
    .filter((s) => s.empresaId === id)
    .sort((a, b) => aEpoch(a.fechaHora) - aEpoch(b.fechaHora));
  res.status(200).json(salidas);
};
