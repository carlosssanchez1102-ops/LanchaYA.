const db = require('../db');

const redondear = (n) => Math.round(n * 100) / 100;

// GET /api/estadisticas
exports.obtener = (req, res) => {
  const salidas = db.read('salidas');
  const reservas = db.read('reservas');
  const empresas = db.read('empresas');

  const porDestino = new Map();
  const porTipo = new Map();
  const porEstado = new Map();
  let sumaPrecios = 0;

  for (const s of salidas) {
    const d = porDestino.get(s.destino) || { destino: s.destino, total: 0, sumaPrecios: 0 };
    d.total += 1;
    d.sumaPrecios += s.precio;
    porDestino.set(s.destino, d);

    porTipo.set(s.tipo, (porTipo.get(s.tipo) || 0) + 1);
    porEstado.set(s.estado, (porEstado.get(s.estado) || 0) + 1);
    sumaPrecios += s.precio;
  }

  res.status(200).json({
    totalSalidas: salidas.length,
    totalEmpresas: empresas.length,
    totalReservas: reservas.length,
    cuposReservados: reservas.reduce((suma, r) => suma + r.cantidad, 0),
    precioPromedio: salidas.length ? redondear(sumaPrecios / salidas.length) : 0,
    porDestino: [...porDestino.values()]
      .map((d) => ({ destino: d.destino, total: d.total, precioPromedio: redondear(d.sumaPrecios / d.total) }))
      .sort((a, b) => b.total - a.total || a.destino.localeCompare(b.destino, 'es')),
    porTipo: [...porTipo.entries()].map(([tipo, total]) => ({ tipo, total })),
    porEstado: [...porEstado.entries()].map(([estado, total]) => ({ estado, total })),
  });
};
