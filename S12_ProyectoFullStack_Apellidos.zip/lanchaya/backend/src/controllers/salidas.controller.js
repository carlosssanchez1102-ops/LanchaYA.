const db = require('../db');
const { validateSalida, validateEstado, TIPOS, quitarTildes } = require('../validators');
const { notFound, validacion, parseId } = require('../utils/errors');
const { aEpoch, hoyLima, esFechaValida } = require('../utils/fechas');

const norm = (s) => quitarTildes(String(s)).toLowerCase().trim();
const primero = (v) => (Array.isArray(v) ? v[0] : v);
const vacio = (v) => v === undefined || v === null || v === '';
const verdadero = (v) => ['true', '1', 'si', 'sí'].includes(String(primero(v)).toLowerCase());
const HORAS_48 = 48 * 60 * 60 * 1000;

function buscar(id) {
  const salida = db.read('salidas').find((s) => s.id === id);
  if (!salida) throw notFound(`No existe la salida con id ${id}`);
  return salida;
}

// GET /api/salidas
// Filtros: destino, fecha (YYYY-MM-DD), tipo, q, precioMin, precioMax, hoy, proximas48, estado
// Orden: orden=fecha|precio|duracion & dir=asc|desc
// Paginación (opcional): page, limit. Devuelve siempre un arreglo; el total viene en X-Total-Count.
exports.listar = (req, res) => {
  const q = {};
  for (const k of Object.keys(req.query)) q[k] = primero(req.query[k]);
  const errores = [];

  if (!vacio(q.tipo) && !TIPOS.includes(norm(q.tipo))) errores.push(`tipo solo acepta: ${TIPOS.join(', ')}`);
  if (!vacio(q.fecha) && !esFechaValida(q.fecha)) errores.push('fecha debe tener formato YYYY-MM-DD');

  const precioMin = vacio(q.precioMin) ? null : Number(q.precioMin);
  const precioMax = vacio(q.precioMax) ? null : Number(q.precioMax);
  if (precioMin !== null && !Number.isFinite(precioMin)) errores.push('precioMin debe ser un número');
  if (precioMax !== null && !Number.isFinite(precioMax)) errores.push('precioMax debe ser un número');

  const orden = vacio(q.orden) ? 'fecha' : String(q.orden).toLowerCase();
  const dir = vacio(q.dir) ? 'asc' : String(q.dir).toLowerCase();
  if (!['fecha', 'precio', 'duracion'].includes(orden)) errores.push('orden solo acepta: fecha, precio, duracion');
  if (!['asc', 'desc'].includes(dir)) errores.push('dir solo acepta: asc, desc');

  const paginar = !vacio(q.page) || !vacio(q.limit);
  const page = vacio(q.page) ? 1 : Number(q.page);
  const limit = vacio(q.limit) ? 10 : Number(q.limit);
  if (paginar) {
    if (!Number.isInteger(page) || page < 1) errores.push('page debe ser un entero mayor o igual a 1');
    if (!Number.isInteger(limit) || limit < 1 || limit > 100) errores.push('limit debe ser un entero entre 1 y 100');
  }
  if (errores.length) throw validacion(errores);

  let items = db.read('salidas');
  const ahora = Date.now();

  if (!vacio(q.destino)) items = items.filter((s) => norm(s.destino) === norm(q.destino));
  if (!vacio(q.tipo)) items = items.filter((s) => s.tipo === norm(q.tipo));
  if (!vacio(q.fecha)) items = items.filter((s) => s.fechaHora.startsWith(q.fecha));
  if (!vacio(q.estado)) items = items.filter((s) => s.estado === q.estado || norm(s.estado) === norm(q.estado));
  if (!vacio(q.q)) {
    const texto = norm(q.q);
    items = items.filter((s) => norm(s.empresa).includes(texto) || norm(s.embarcacion).includes(texto));
  }
  if (precioMin !== null) items = items.filter((s) => s.precio >= precioMin);
  if (precioMax !== null) items = items.filter((s) => s.precio <= precioMax);
  if (verdadero(q.hoy)) {
    const hoy = hoyLima();
    items = items.filter((s) => s.fechaHora.startsWith(hoy));
  }
  if (verdadero(q.proximas48)) {
    items = items.filter((s) => {
      const t = aEpoch(s.fechaHora);
      return t >= ahora && t <= ahora + HORAS_48;
    });
  }

  const clave = { fecha: (s) => aEpoch(s.fechaHora), precio: (s) => s.precio, duracion: (s) => s.duracionHoras }[orden];
  const signo = dir === 'desc' ? -1 : 1;
  items.sort((a, b) => signo * (clave(a) - clave(b)) || aEpoch(a.fechaHora) - aEpoch(b.fechaHora) || a.id - b.id);

  const total = items.length;
  res.set('X-Total-Count', String(total));
  if (paginar) {
    res.set('X-Page', String(page));
    res.set('X-Total-Pages', String(Math.max(1, Math.ceil(total / limit))));
    items = items.slice((page - 1) * limit, page * limit);
  }
  res.status(200).json(items);
};

// GET /api/salidas/:id
exports.obtener = (req, res) => {
  res.status(200).json(buscar(parseId(req.params.id)));
};

// POST /api/salidas
exports.crear = (req, res) => {
  const { errores, valor } = validateSalida(req.body, { empresas: db.read('empresas') });
  if (errores.length) throw validacion(errores);

  const salidas = db.read('salidas');
  const nueva = { id: db.nextId(salidas), ...valor };
  salidas.push(nueva);
  db.write('salidas', salidas);
  res.status(201).json(nueva);
};

// PUT /api/salidas/:id
exports.actualizar = (req, res) => {
  const id = parseId(req.params.id);
  const salidas = db.read('salidas');
  const indice = salidas.findIndex((s) => s.id === id);
  if (indice === -1) throw notFound(`No existe la salida con id ${id}`);

  const { errores, valor } = validateSalida(req.body, {
    empresas: db.read('empresas'),
    existing: salidas[indice],
  });
  if (errores.length) throw validacion(errores);

  salidas[indice] = { id, ...valor };
  db.write('salidas', salidas);
  res.status(200).json(salidas[indice]);
};

// DELETE /api/salidas/:id  (también elimina sus reservas)
exports.eliminar = (req, res) => {
  const id = parseId(req.params.id);
  const salidas = db.read('salidas');
  if (!salidas.some((s) => s.id === id)) throw notFound(`No existe la salida con id ${id}`);

  db.write('salidas', salidas.filter((s) => s.id !== id));
  db.write('reservas', db.read('reservas').filter((r) => r.salidaId !== id));
  res.status(204).send();
};

// PATCH /api/salidas/:id/estado
exports.cambiarEstado = (req, res) => {
  const id = parseId(req.params.id);
  const salidas = db.read('salidas');
  const salida = salidas.find((s) => s.id === id);
  if (!salida) throw notFound(`No existe la salida con id ${id}`);

  const { errores, estado } = validateEstado(req.body);
  if (errores.length) throw validacion(errores);

  salida.estado = estado;
  db.write('salidas', salidas);
  res.status(200).json(salida);
};

// GET /api/destinos  -> ["Caballococha", "Nauta", ...] sin repetir
exports.destinos = (req, res) => {
  const vistos = new Map();
  for (const s of db.read('salidas')) {
    if (!vistos.has(norm(s.destino))) vistos.set(norm(s.destino), s.destino);
  }
  res.status(200).json([...vistos.values()].sort((a, b) => a.localeCompare(b, 'es')));
};
