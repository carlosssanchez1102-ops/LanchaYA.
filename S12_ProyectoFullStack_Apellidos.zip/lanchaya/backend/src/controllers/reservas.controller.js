const db = require('../db');
const { validateReserva } = require('../validators');
const { notFound, conflict, validacion, parseId } = require('../utils/errors');

const ALFABETO = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789'; // sin 0/O, 1/I/L para evitar confusiones

function generarCodigo(reservas) {
  const usados = new Set(reservas.map((r) => r.codigo));
  let codigo;
  do {
    let sufijo = '';
    for (let i = 0; i < 5; i += 1) sufijo += ALFABETO[Math.floor(Math.random() * ALFABETO.length)];
    codigo = `LY-${sufijo}`;
  } while (usados.has(codigo));
  return codigo;
}

function buscarSalida(id) {
  const salidas = db.read('salidas');
  const salida = salidas.find((s) => s.id === id);
  if (!salida) throw notFound(`No existe la salida con id ${id}`);
  return { salidas, salida };
}

// POST /api/salidas/:id/reservas
exports.crear = (req, res) => {
  const salidaId = parseId(req.params.id);
  const { salidas, salida } = buscarSalida(salidaId);

  const { errores, valor } = validateReserva(req.body);
  if (errores.length) throw validacion(errores);

  if (salida.estado === 'zarpó' || salida.estado === 'cancelada') {
    throw conflict(`La salida está "${salida.estado}" y ya no acepta reservas`);
  }
  if (valor.cantidad > salida.cupos) {
    throw conflict(
      salida.cupos === 0
        ? 'No quedan cupos disponibles en esta salida'
        : `No hay cupos suficientes: quedan ${salida.cupos} y pediste ${valor.cantidad}`
    );
  }

  const reservas = db.read('reservas');
  const nueva = {
    id: db.nextId(reservas),
    codigo: generarCodigo(reservas),
    salidaId,
    ...valor,
    creadaEn: new Date().toISOString(),
  };
  reservas.push(nueva);
  salida.cupos -= valor.cantidad;

  db.write('reservas', reservas);
  db.write('salidas', salidas);
  res.status(201).json(nueva);
};

// GET /api/salidas/:id/reservas
exports.listarPorSalida = (req, res) => {
  const salidaId = parseId(req.params.id);
  buscarSalida(salidaId);
  res.status(200).json(db.read('reservas').filter((r) => r.salidaId === salidaId));
};

// DELETE /api/reservas/:id  (el cupo vuelve a la salida)
exports.cancelar = (req, res) => {
  const id = parseId(req.params.id);
  const reservas = db.read('reservas');
  const reserva = reservas.find((r) => r.id === id);
  if (!reserva) throw notFound(`No existe la reserva con id ${id}`);

  const salidas = db.read('salidas');
  const salida = salidas.find((s) => s.id === reserva.salidaId);
  if (salida) {
    salida.cupos = Math.min(salida.capacidad, salida.cupos + reserva.cantidad);
    db.write('salidas', salidas);
  }
  db.write('reservas', reservas.filter((r) => r.id !== id));
  res.status(204).send();
};

// GET /api/reservas/:codigo
exports.consultarPorCodigo = (req, res) => {
  const codigo = String(req.params.codigo).trim().toUpperCase();
  const reserva = db.read('reservas').find((r) => r.codigo === codigo);
  if (!reserva) throw notFound(`No existe una reserva con el código ${codigo}`);

  const salida = db.read('salidas').find((s) => s.id === reserva.salidaId) || null;
  res.status(200).json({
    ...reserva,
    total: salida ? Math.round(salida.precio * reserva.cantidad * 100) / 100 : null,
    salida: salida && {
      id: salida.id,
      empresa: salida.empresa,
      embarcacion: salida.embarcacion,
      tipo: salida.tipo,
      destino: salida.destino,
      puerto: salida.puerto,
      fechaHora: salida.fechaHora,
      precio: salida.precio,
      estado: salida.estado,
    },
  });
};
