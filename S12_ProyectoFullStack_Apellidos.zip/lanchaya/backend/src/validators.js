const { esFechaHoraValida, aEpoch } = require('./utils/fechas');

const TIPOS = ['lancha', 'rapido', 'deslizador'];
const ESTADOS = ['programada', 'abordando', 'zarpó', 'cancelada'];

const RE_RUC = /^\d{11}$/;
const RE_DNI = /^\d{8}$/;
const RE_TELEFONO = /^\+?\d[\d\s-]{5,14}$/;

const texto = (v) => (typeof v === 'string' ? v.trim() : '');
const quitarTildes = (s) => s.normalize('NFD').replace(/[̀-ͯ]/g, '');

function numero(v) {
  if (typeof v === 'number') return v;
  if (typeof v === 'string' && v.trim() !== '') return Number(v);
  return NaN;
}

function normalizarEstado(valor) {
  const e = quitarTildes(texto(valor).toLowerCase());
  if (e === 'zarpo') return 'zarpó';
  return ESTADOS.find((x) => quitarTildes(x) === e) || null;
}

/**
 * Valida el cuerpo de POST/PUT /api/salidas.
 * - `empresas`: lista de empresas para resolver empresaId.
 * - `existing`: la salida actual (solo en PUT). Permite no exigir "fecha futura"
 *   si la fecha no cambió y conservar las reservas ya hechas.
 * Devuelve { errores, valor }.
 */
function validateSalida(body, { empresas = [], existing = null } = {}) {
  const b = body && typeof body === 'object' ? body : {};
  const errores = [];

  let empresaId = null;
  let empresa = texto(b.empresa);
  if (b.empresaId !== undefined && b.empresaId !== null && b.empresaId !== '') {
    const id = Number(b.empresaId);
    const encontrada = Number.isInteger(id) ? empresas.find((e) => e.id === id) : null;
    if (!encontrada) {
      errores.push('empresaId no corresponde a ninguna empresa registrada');
    } else {
      empresaId = encontrada.id;
      empresa = encontrada.razonSocial;
    }
  }
  if (!empresa) errores.push('empresa es obligatoria');

  const destino = texto(b.destino);
  if (!destino) errores.push('destino es obligatorio');

  const puerto = texto(b.puerto);
  if (!puerto) errores.push('puerto es obligatorio');

  const tipo = quitarTildes(texto(b.tipo).toLowerCase());
  if (!TIPOS.includes(tipo)) errores.push(`tipo solo acepta: ${TIPOS.join(', ')}`);

  let fechaHora = texto(b.fechaHora);
  if (!fechaHora) {
    errores.push('fechaHora es obligatoria');
  } else if (!esFechaHoraValida(fechaHora)) {
    errores.push('fechaHora debe tener formato ISO 8601 válido (ej.: 2026-11-20T06:30)');
  } else {
    fechaHora = fechaHora.slice(0, 16);
    const cambio = !existing || existing.fechaHora.slice(0, 16) !== fechaHora;
    if (cambio && aEpoch(fechaHora) < Date.now()) {
      errores.push('fechaHora no puede estar en el pasado');
    }
  }

  const precio = numero(b.precio);
  if (!Number.isFinite(precio) || precio <= 0) errores.push('precio debe ser un número mayor que 0');

  const duracionHoras = numero(b.duracionHoras);
  if (!Number.isFinite(duracionHoras) || duracionHoras <= 0) {
    errores.push('duracionHoras debe ser un número mayor que 0');
  }

  // `capacidad` (o `cupos`, si no se envía capacidad) es el total de asientos.
  // La respuesta devuelve `cupos` = asientos disponibles.
  const reservados = existing ? existing.capacidad - existing.cupos : 0;
  const crudo = b.capacidad !== undefined && b.capacidad !== '' ? b.capacidad : b.cupos;
  const capacidad = numero(crudo);
  if (!Number.isInteger(capacidad) || capacidad < 1) {
    errores.push('cupos debe ser un número entero mayor o igual a 1');
  } else if (capacidad < reservados) {
    errores.push(`la capacidad no puede ser menor que los ${reservados} cupos ya reservados`);
  }

  let estado = existing ? existing.estado : 'programada';
  if (b.estado !== undefined && b.estado !== '') {
    const e = normalizarEstado(b.estado);
    if (!e) errores.push(`estado solo acepta: ${ESTADOS.join(', ')}`);
    else estado = e;
  }

  return {
    errores,
    valor: {
      empresaId,
      empresa,
      embarcacion: texto(b.embarcacion),
      tipo,
      destino,
      puerto,
      fechaHora,
      duracionHoras,
      precio,
      capacidad,
      cupos: capacidad - reservados,
      estado,
    },
  };
}

function validateEmpresa(body) {
  const b = body && typeof body === 'object' ? body : {};
  const errores = [];
  const razonSocial = texto(b.razonSocial);
  const ruc = texto(String(b.ruc ?? ''));
  const telefono = texto(String(b.telefono ?? ''));
  const puertoBase = texto(b.puertoBase);

  if (!razonSocial) errores.push('razonSocial es obligatoria');
  if (!RE_RUC.test(ruc)) errores.push('ruc debe tener exactamente 11 dígitos');
  if (!RE_TELEFONO.test(telefono)) errores.push('telefono no es válido (use de 6 a 15 dígitos)');
  if (!puertoBase) errores.push('puertoBase es obligatorio');

  return { errores, valor: { razonSocial, ruc, telefono, puertoBase } };
}

function validateReserva(body) {
  const b = body && typeof body === 'object' ? body : {};
  const errores = [];
  const nombre = texto(b.nombre);
  const dni = texto(String(b.dni ?? ''));
  const telefono = texto(String(b.telefono ?? ''));
  const cantidad = numero(b.cantidad);

  if (nombre.length < 3) errores.push('nombre es obligatorio (mínimo 3 caracteres)');
  if (!RE_DNI.test(dni)) errores.push('dni debe tener exactamente 8 dígitos');
  if (!RE_TELEFONO.test(telefono)) errores.push('telefono no es válido (use de 6 a 15 dígitos)');
  if (!Number.isInteger(cantidad) || cantidad < 1) {
    errores.push('cantidad de pasajes debe ser un entero mayor o igual a 1');
  }

  return { errores, valor: { nombre, dni, telefono, cantidad } };
}

function validateEstado(body) {
  const estado = normalizarEstado(body && body.estado);
  const errores = estado ? [] : [`estado solo acepta: ${ESTADOS.join(', ')}`];
  return { errores, estado };
}

module.exports = {
  TIPOS,
  ESTADOS,
  quitarTildes,
  validateSalida,
  validateEmpresa,
  validateReserva,
  validateEstado,
};
