const { Router } = require('express');
const empresas = require('../controllers/empresas.controller');

const router = Router();

router.get('/', empresas.listar);
router.post('/', empresas.crear);
router.get('/:id', empresas.obtener);
router.put('/:id', empresas.actualizar);
router.delete('/:id', empresas.eliminar);
router.get('/:id/salidas', empresas.salidas);

module.exports = router;
