const { Router } = require('express');
const salidas = require('../controllers/salidas.controller');
const reservas = require('../controllers/reservas.controller');

const router = Router();

router.get('/', salidas.listar);
router.post('/', salidas.crear);
router.get('/:id', salidas.obtener);
router.put('/:id', salidas.actualizar);
router.delete('/:id', salidas.eliminar);
router.patch('/:id/estado', salidas.cambiarEstado);

router.get('/:id/reservas', reservas.listarPorSalida);
router.post('/:id/reservas', reservas.crear);

module.exports = router;
