const { Router } = require('express');
const reservas = require('../controllers/reservas.controller');

const router = Router();

router.get('/:codigo', reservas.consultarPorCodigo);
router.delete('/:id', reservas.cancelar);

module.exports = router;
