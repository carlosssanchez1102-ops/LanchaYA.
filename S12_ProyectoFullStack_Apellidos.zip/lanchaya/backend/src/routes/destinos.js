const { Router } = require('express');
const salidas = require('../controllers/salidas.controller');

const router = Router();

router.get('/', salidas.destinos);

module.exports = router;
