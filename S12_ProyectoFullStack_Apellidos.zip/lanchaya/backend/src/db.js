// Persistencia en archivos JSON. Cada "tabla" es un arreglo en DATA_PATH/<nombre>.json
const fs = require('fs');
const path = require('path');

function carpetaDatos() {
  return path.resolve(process.env.DATA_PATH || path.join(__dirname, 'data'));
}

function archivo(nombre) {
  return path.join(carpetaDatos(), `${nombre}.json`);
}

function read(nombre) {
  const ruta = archivo(nombre);
  if (!fs.existsSync(ruta)) return [];
  const texto = fs.readFileSync(ruta, 'utf8').trim();
  return texto ? JSON.parse(texto) : [];
}

// Escribe en un temporal y renombra, para no dejar el JSON a medias si algo falla.
function write(nombre, datos) {
  const ruta = archivo(nombre);
  fs.mkdirSync(path.dirname(ruta), { recursive: true });
  const tmp = `${ruta}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(datos, null, 2), 'utf8');
  fs.renameSync(tmp, ruta);
}

function nextId(lista) {
  return lista.reduce((max, item) => Math.max(max, item.id), 0) + 1;
}

module.exports = { read, write, nextId };
