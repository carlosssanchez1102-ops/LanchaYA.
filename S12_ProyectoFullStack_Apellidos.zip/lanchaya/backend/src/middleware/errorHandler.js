// Todas las respuestas de error tienen la forma { error: true, mensaje: "..." }
function notFoundHandler(req, res) {
  res.status(404).json({
    error: true,
    mensaje: `Ruta no encontrada: ${req.method} ${req.originalUrl}`,
  });
}

// eslint-disable-next-line no-unused-vars
function errorHandler(err, req, res, next) {
  if (err.type === 'entity.parse.failed') {
    return res.status(400).json({ error: true, mensaje: 'El cuerpo de la petición no es un JSON válido' });
  }
  const status = err.status || err.statusCode || 500;
  if (status >= 500) console.error(err);
  const cuerpo = {
    error: true,
    mensaje: status >= 500 ? 'Error interno del servidor' : err.message,
  };
  if (err.errores) cuerpo.errores = err.errores;
  res.status(status).json(cuerpo);
}

module.exports = { notFoundHandler, errorHandler };
