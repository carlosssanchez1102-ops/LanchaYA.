require('dotenv').config();

const express = require('express');
const cors = require('cors');
const logger = require('./middleware/logger');
const { notFoundHandler, errorHandler } = require('./middleware/errorHandler');

const app = express();

app.use(cors({ exposedHeaders: ['X-Total-Count', 'X-Total-Pages', 'X-Page'] }));
app.use(express.json());
app.use(logger);

app.get('/api/health', (req, res) => res.status(200).json({ ok: true, servicio: 'LanchaYa Iquitos' }));
app.use('/api/salidas', require('./routes/salidas'));
app.use('/api/destinos', require('./routes/destinos'));
app.use('/api/empresas', require('./routes/empresas'));
app.use('/api/reservas', require('./routes/reservas'));
app.use('/api/estadisticas', require('./routes/estadisticas'));

app.use(notFoundHandler);
app.use(errorHandler);

const PORT = process.env.PORT || 3000;

if (require.main === module) {
  app.listen(PORT, () => console.log(`LanchaYa API escuchando en http://localhost:${PORT}`));
}

module.exports = app;
