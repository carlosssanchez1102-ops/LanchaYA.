import { ahoraLima } from './format.js';

// Misma lógica que backend/src/validators.js. Devuelven un objeto { campo: "mensaje" }.
const RE_TELEFONO = /^\+?\d[\d\s-]{5,14}$/;

export function validarSalida(f, { original = null, reservados = 0 } = {}) {
  const e = {};
  if (!String(f.empresaId ?? '').trim()) e.empresaId = 'Elige una empresa';
  if (!f.tipo) e.tipo = 'Elige el tipo de embarcación';
  if (!f.destino.trim()) e.destino = 'El destino es obligatorio';
  if (!f.puerto.trim()) e.puerto = 'El puerto es obligatorio';

  if (!f.fechaHora) {
    e.fechaHora = 'La fecha y hora son obligatorias';
  } else {
    const cambio = !original || original.fechaHora.slice(0, 16) !== f.fechaHora.slice(0, 16);
    if (cambio && f.fechaHora < ahoraLima()) e.fechaHora = 'La salida no puede estar en el pasado';
  }

  const precio = Number(f.precio);
  if (f.precio === '' || !Number.isFinite(precio) || precio <= 0) e.precio = 'El precio debe ser mayor que 0';

  const dur = Number(f.duracionHoras);
  if (f.duracionHoras === '' || !Number.isFinite(dur) || dur <= 0) e.duracionHoras = 'La duración debe ser mayor que 0';

  const cap = Number(f.capacidad);
  if (f.capacidad === '' || !Number.isInteger(cap) || cap < 1) e.capacidad = 'Los cupos deben ser un entero de 1 o más';
  else if (cap < reservados) e.capacidad = `Ya hay ${reservados} cupos reservados; no puede ser menor`;
  return e;
}

export function validarEmpresa(f) {
  const e = {};
  if (!f.razonSocial.trim()) e.razonSocial = 'La razón social es obligatoria';
  if (!/^\d{11}$/.test(f.ruc.trim())) e.ruc = 'El RUC debe tener 11 dígitos';
  if (!RE_TELEFONO.test(f.telefono.trim())) e.telefono = 'Teléfono no válido (6 a 15 dígitos)';
  if (!f.puertoBase.trim()) e.puertoBase = 'El puerto base es obligatorio';
  return e;
}

export function validarReserva(f, cuposDisponibles) {
  const e = {};
  if (f.nombre.trim().length < 3) e.nombre = 'Escribe tu nombre completo';
  if (!/^\d{8}$/.test(f.dni.trim())) e.dni = 'El DNI debe tener 8 dígitos';
  if (!RE_TELEFONO.test(f.telefono.trim())) e.telefono = 'Teléfono no válido (6 a 15 dígitos)';
  const c = Number(f.cantidad);
  if (!Number.isInteger(c) || c < 1) e.cantidad = 'Mínimo 1 pasaje';
  else if (c > cuposDisponibles) e.cantidad = `Solo quedan ${cuposDisponibles} cupos`;
  return e;
}
