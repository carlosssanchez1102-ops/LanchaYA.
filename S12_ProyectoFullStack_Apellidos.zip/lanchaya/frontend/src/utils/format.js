// Las fechas llegan como "YYYY-MM-DDTHH:mm" y son hora de Iquitos (UTC-5).
const OFFSET_LIMA = '-05:00';

export const TIPOS = [
  { valor: 'lancha', etiqueta: 'Lancha' },
  { valor: 'rapido', etiqueta: 'Rápido' },
  { valor: 'deslizador', etiqueta: 'Deslizador' },
];

export const ESTADOS = [
  { valor: 'programada', etiqueta: 'Programada' },
  { valor: 'abordando', etiqueta: 'Abordando' },
  { valor: 'zarpó', etiqueta: 'Zarpó' },
  { valor: 'cancelada', etiqueta: 'Cancelada' },
];

export const PUERTOS = ['Puerto Henry', 'Puerto Masusa', 'Puerto Productores', 'Puerto Bellavista Nanay'];

export const etiquetaTipo = (v) => TIPOS.find((t) => t.valor === v)?.etiqueta ?? v;
export const etiquetaEstado = (v) => ESTADOS.find((e) => e.valor === v)?.etiqueta ?? v;

export function aDate(fechaHora) {
  if (!fechaHora) return new Date(NaN);
  const conSegundos = fechaHora.length === 16 ? `${fechaHora}:00` : fechaHora;
  return new Date(`${conSegundos}${OFFSET_LIMA}`);
}

const fmtFecha = new Intl.DateTimeFormat('es-PE', {
  weekday: 'short',
  day: 'numeric',
  month: 'short',
  timeZone: 'America/Lima',
});
const fmtHora = new Intl.DateTimeFormat('es-PE', {
  hour: '2-digit',
  minute: '2-digit',
  hour12: false,
  timeZone: 'America/Lima',
});

export const formatFecha = (f) => fmtFecha.format(aDate(f)).replace(/\./g, '');
export const formatHora = (f) => fmtHora.format(aDate(f));
export const formatPrecio = (n) => `S/ ${Number(n).toFixed(2)}`;

export function formatDuracion(horas) {
  if (horas < 24) return `${horas} h`;
  const d = Math.floor(horas / 24);
  const r = Math.round((horas % 24) * 10) / 10;
  return r ? `${d} d ${r} h` : `${d} d`;
}

// "YYYY-MM-DDTHH:mm" de ahora mismo en Iquitos (para el atributo min del input)
export function ahoraLima() {
  return new Date(Date.now() - 5 * 3600 * 1000).toISOString().slice(0, 16);
}

export function porcentajeCupos(salida) {
  return salida.capacidad > 0 ? (salida.cupos / salida.capacidad) * 100 : 0;
}

// verde > 50 % de cupos libres, amarillo 20-50 %, rojo < 20 %
export function colorCupos(salida) {
  const p = porcentajeCupos(salida);
  if (p > 50) return 'verde';
  if (p >= 20) return 'amarillo';
  return 'rojo';
}

export function mensajeWhatsApp(salida) {
  const texto =
    `🚤 ${salida.empresa} - ${etiquetaTipo(salida.tipo)}${salida.embarcacion ? ` "${salida.embarcacion}"` : ''}\n` +
    `Destino: ${salida.destino}\n` +
    `Fecha: ${formatFecha(salida.fechaHora)}\n` +
    `Hora: ${formatHora(salida.fechaHora)}\n` +
    `Puerto: ${salida.puerto}\n` +
    `Pasaje: ${formatPrecio(salida.precio)}\n` +
    `Más info en LanchaYa: ${window.location.origin}/salidas/${salida.id}`;
  return `https://wa.me/?text=${encodeURIComponent(texto)}`;
}
