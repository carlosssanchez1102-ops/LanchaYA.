import { createContext, useContext, useEffect, useState } from 'react';

const TemaContext = createContext({ tema: 'claro', alternar: () => {} });

function temaInicial() {
  try {
    const guardado = window.localStorage.getItem('lanchaya.tema');
    if (guardado === 'claro' || guardado === 'oscuro') return guardado;
  } catch {
    /* sin localStorage */
  }
  return window.matchMedia?.('(prefers-color-scheme: dark)').matches ? 'oscuro' : 'claro';
}

export function TemaProvider({ children }) {
  const [tema, setTema] = useState(temaInicial);

  useEffect(() => {
    document.documentElement.dataset.tema = tema;
    try {
      window.localStorage.setItem('lanchaya.tema', tema);
    } catch {
      /* sin localStorage */
    }
  }, [tema]);

  const alternar = () => setTema((t) => (t === 'claro' ? 'oscuro' : 'claro'));
  return <TemaContext.Provider value={{ tema, alternar }}>{children}</TemaContext.Provider>;
}

export const useTema = () => useContext(TemaContext);
