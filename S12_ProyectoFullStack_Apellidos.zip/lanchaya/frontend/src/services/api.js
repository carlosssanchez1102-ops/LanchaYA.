const BASE = (import.meta.env.VITE_API_URL || 'http://localhost:3000/api').replace(/\/$/, '');

export class ApiError extends Error {
  constructor(mensaje, status, errores) {
    super(mensaje);
    this.status = status;
    this.errores = errores;
  }
}

function queryString(params) {
  const sp = new URLSearchParams();
  Object.entries(params || {}).forEach(([k, v]) => {
    if (v !== '' && v !== null && v !== undefined && v !== false) sp.append(k, v);
  });
  const s = sp.toString();
  return s ? `?${s}` : '';
}

async function request(path, { method = 'GET', body, params } = {}) {
  let res;
  try {
    res = await fetch(`${BASE}${path}${queryString(params)}`, {
      method,
      headers: body !== undefined ? { 'Content-Type': 'application/json' } : undefined,
      body: body !== undefined ? JSON.stringify(body) : undefined,
    });
  } catch {
    throw new ApiError('No se pudo conectar con el servidor. Revisa tu conexión e inténtalo de nuevo.', 0);
  }
  if (res.status === 204) return { data: null, res };
  let data = null;
  try {
    data = await res.json();
  } catch {
    /* respuesta sin JSON */
  }
  if (!res.ok) throw new ApiError(data?.mensaje || `Error del servidor (${res.status})`, res.status, data?.errores);
  return { data, res };
}

// ---------- Salidas ----------
export async function listarSalidas(params) {
  const { data, res } = await request('/salidas', { params });
  return {
    items: data,
    total: Number(res.headers.get('X-Total-Count') ?? data.length),
    totalPaginas: Number(res.headers.get('X-Total-Pages') ?? 1),
  };
}
export const obtenerSalida = (id) => request(`/salidas/${id}`).then((r) => r.data);
export const crearSalida = (salida) => request('/salidas', { method: 'POST', body: salida }).then((r) => r.data);
export const actualizarSalida = (id, salida) =>
  request(`/salidas/${id}`, { method: 'PUT', body: salida }).then((r) => r.data);
export const eliminarSalida = (id) => request(`/salidas/${id}`, { method: 'DELETE' });
export const cambiarEstado = (id, estado) =>
  request(`/salidas/${id}/estado`, { method: 'PATCH', body: { estado } }).then((r) => r.data);
export const listarDestinos = () => request('/destinos').then((r) => r.data);

// ---------- Empresas ----------
export const listarEmpresas = () => request('/empresas').then((r) => r.data);
export const crearEmpresa = (empresa) => request('/empresas', { method: 'POST', body: empresa }).then((r) => r.data);
export const actualizarEmpresa = (id, empresa) =>
  request(`/empresas/${id}`, { method: 'PUT', body: empresa }).then((r) => r.data);
export const eliminarEmpresa = (id) => request(`/empresas/${id}`, { method: 'DELETE' });
export const salidasDeEmpresa = (id) => request(`/empresas/${id}/salidas`).then((r) => r.data);

// ---------- Reservas ----------
export const crearReserva = (salidaId, reserva) =>
  request(`/salidas/${salidaId}/reservas`, { method: 'POST', body: reserva }).then((r) => r.data);
export const consultarReserva = (codigo) => request(`/reservas/${encodeURIComponent(codigo)}`).then((r) => r.data);
export const cancelarReserva = (id) => request(`/reservas/${id}`, { method: 'DELETE' });

// ---------- Estadísticas ----------
export const obtenerEstadisticas = () => request('/estadisticas').then((r) => r.data);
