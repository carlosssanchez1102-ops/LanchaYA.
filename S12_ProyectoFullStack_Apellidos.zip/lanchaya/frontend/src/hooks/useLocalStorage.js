import { useEffect, useState } from 'react';

export default function useLocalStorage(clave, inicial) {
  const [valor, setValor] = useState(() => {
    try {
      const guardado = window.localStorage.getItem(clave);
      return guardado ? { ...inicial, ...JSON.parse(guardado) } : inicial;
    } catch {
      return inicial;
    }
  });

  useEffect(() => {
    try {
      window.localStorage.setItem(clave, JSON.stringify(valor));
    } catch {
      /* almacenamiento no disponible */
    }
  }, [clave, valor]);

  return [valor, setValor];
}
