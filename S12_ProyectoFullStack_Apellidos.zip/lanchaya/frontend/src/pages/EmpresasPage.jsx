import { useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import ConfirmModal from '../components/ConfirmModal.jsx';
import EmpresaForm from '../components/EmpresaForm.jsx';
import { Cargando, ErrorConexion, Vacio } from '../components/Estados.jsx';
import EstadoBadge from '../components/EstadoBadge.jsx';
import { useToast } from '../context/ToastContext.jsx';
import {
  actualizarEmpresa,
  crearEmpresa,
  eliminarEmpresa,
  listarEmpresas,
  salidasDeEmpresa,
} from '../services/api.js';
import { formatFecha, formatHora } from '../utils/format.js';

export default function EmpresasPage() {
  const toast = useToast();
  const [empresas, setEmpresas] = useState([]);
  const [estado, setEstado] = useState('cargando');
  const [error, setError] = useState('');
  const [recarga, setRecarga] = useState(0);

  const [enEdicion, setEnEdicion] = useState(null);
  const [enviando, setEnviando] = useState(false);
  const [errorServidor, setErrorServidor] = useState('');
  const [aEliminar, setAEliminar] = useState(null);
  const [eliminando, setEliminando] = useState(false);

  const [abierta, setAbierta] = useState(null);
  const [salidas, setSalidas] = useState({ cargando: false, items: [], error: '' });

  useEffect(() => {
    let vigente = true;
    setEstado('cargando');
    listarEmpresas()
      .then((e) => {
        if (!vigente) return;
        setEmpresas(e);
        setEstado('ok');
      })
      .catch((e) => {
        if (!vigente) return;
        setError(e.message);
        setEstado('error');
      });
    return () => {
      vigente = false;
    };
  }, [recarga]);

  const guardar = async (datos) => {
    setEnviando(true);
    setErrorServidor('');
    try {
      if (enEdicion) {
        await actualizarEmpresa(enEdicion.id, datos);
        toast.exito('Empresa actualizada');
      } else {
        await crearEmpresa(datos);
        toast.exito('Empresa registrada');
      }
      setEnEdicion(null);
      setRecarga((n) => n + 1);
    } catch (e) {
      setErrorServidor(e.message);
      toast.error(e.message);
    } finally {
      setEnviando(false);
    }
  };

  const confirmarEliminar = useCallback(async () => {
    setEliminando(true);
    try {
      await eliminarEmpresa(aEliminar.id);
      toast.exito('Empresa eliminada');
      if (enEdicion?.id === aEliminar.id) setEnEdicion(null);
      setAEliminar(null);
      setRecarga((n) => n + 1);
    } catch (e) {
      // 409: la empresa tiene salidas futuras
      toast.error(e.message);
      setAEliminar(null);
    } finally {
      setEliminando(false);
    }
  }, [aEliminar, enEdicion, toast]);

  const alternarSalidas = async (empresa) => {
    if (abierta === empresa.id) {
      setAbierta(null);
      return;
    }
    setAbierta(empresa.id);
    setSalidas({ cargando: true, items: [], error: '' });
    try {
      const items = await salidasDeEmpresa(empresa.id);
      setSalidas({ cargando: false, items, error: '' });
    } catch (e) {
      setSalidas({ cargando: false, items: [], error: e.message });
    }
  };

  return (
    <section>
      <div className="encabezado-pagina">
        <div>
          <h1>Empresas fluviales</h1>
          <p className="subtitulo">Registra tu empresa para publicar tus salidas.</p>
        </div>
      </div>

      <div className="dos-columnas">
        <EmpresaForm
          empresa={enEdicion}
          enviando={enviando}
          errorServidor={errorServidor}
          onGuardar={guardar}
          onCancelar={() => {
            setEnEdicion(null);
            setErrorServidor('');
          }}
        />

        <div>
          {estado === 'cargando' && <Cargando mensaje="Cargando empresas…" />}
          {estado === 'error' && <ErrorConexion mensaje={error} onReintentar={() => setRecarga((n) => n + 1)} />}
          {estado === 'ok' && empresas.length === 0 && (
            <Vacio titulo="Aún no hay empresas" mensaje="Registra la primera con el formulario." />
          )}
          {estado === 'ok' && empresas.length > 0 && (
            <ul className="lista-empresas">
              {empresas.map((e) => (
                <li key={e.id} className="empresa">
                  <div className="empresa-cabecera">
                    <div>
                      <h3>{e.razonSocial}</h3>
                      <p className="tarjeta-empresa">
                        RUC {e.ruc} · {e.telefono} · {e.puertoBase}
                      </p>
                    </div>
                    <div className="empresa-acciones">
                      <button type="button" className="btn btn-secundario" onClick={() => alternarSalidas(e)}>
                        {abierta === e.id ? 'Ocultar salidas' : 'Ver salidas'}
                      </button>
                      <button
                        type="button"
                        className="btn btn-secundario"
                        onClick={() => {
                          setEnEdicion(e);
                          setErrorServidor('');
                          window.scrollTo({ top: 0, behavior: 'smooth' });
                        }}
                      >
                        Editar
                      </button>
                      <button type="button" className="btn btn-peligro-suave" onClick={() => setAEliminar(e)}>
                        Eliminar
                      </button>
                    </div>
                  </div>

                  {abierta === e.id && (
                    <div className="empresa-salidas">
                      {salidas.cargando && <Cargando mensaje="Cargando salidas…" />}
                      {salidas.error && <p className="error-texto">{salidas.error}</p>}
                      {!salidas.cargando && !salidas.error && salidas.items.length === 0 && (
                        <p className="ayuda">Esta empresa no tiene salidas registradas.</p>
                      )}
                      {salidas.items.map((s) => (
                        <Link key={s.id} className="empresa-salida" to={`/salidas/${s.id}`}>
                          <span>
                            {s.destino} · {formatFecha(s.fechaHora)} {formatHora(s.fechaHora)}
                          </span>
                          <EstadoBadge estado={s.estado} />
                        </Link>
                      ))}
                    </div>
                  )}
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>

      <ConfirmModal
        abierto={!!aEliminar}
        titulo="¿Eliminar esta empresa?"
        mensaje={
          aEliminar
            ? `Se eliminará ${aEliminar.razonSocial}. Si tiene salidas futuras, no se podrá eliminar.`
            : ''
        }
        textoConfirmar="Sí, eliminar"
        ocupado={eliminando}
        onConfirmar={confirmarEliminar}
        onCancelar={() => !eliminando && setAEliminar(null)}
      />
    </section>
  );
}
