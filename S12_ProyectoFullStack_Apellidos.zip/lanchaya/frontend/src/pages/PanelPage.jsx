import { useEffect, useState } from 'react';
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { Cargando, ErrorConexion } from '../components/Estados.jsx';
import { useTema } from '../context/TemaContext.jsx';
import { obtenerEstadisticas } from '../services/api.js';
import { etiquetaEstado, etiquetaTipo, formatPrecio } from '../utils/format.js';

function Grafico({ titulo, datos, clave, color, formato }) {
  return (
    <div className="panel-grafico">
      <h2>{titulo}</h2>
      <div className="panel-grafico-lienzo">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={datos} margin={{ top: 8, right: 8, left: -8, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="currentColor" strokeOpacity={0.15} />
            <XAxis dataKey="destino" tick={{ fill: 'currentColor', fontSize: 12 }} interval={0} />
            <YAxis allowDecimals={false} tick={{ fill: 'currentColor', fontSize: 12 }} />
            <Tooltip formatter={(v) => (formato ? formato(v) : v)} />
            <Bar dataKey={clave} fill={color} radius={[4, 4, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}

export default function PanelPage() {
  const { tema } = useTema();
  const [datos, setDatos] = useState(null);
  const [estado, setEstado] = useState('cargando');
  const [error, setError] = useState('');
  const [recarga, setRecarga] = useState(0);

  useEffect(() => {
    let vigente = true;
    setEstado('cargando');
    obtenerEstadisticas()
      .then((d) => {
        if (!vigente) return;
        setDatos(d);
        setEstado('ok');
      })
      .catch((e) => {
        if (!vigente) return;
        setError(e.message);
        setEstado('error');
      });
    return () => {
      vigente = false;
    };
  }, [recarga]);

  const color = tema === 'oscuro' ? '#22d3ee' : '#0e7490';
  const colorPrecio = tema === 'oscuro' ? '#fbbf24' : '#b45309';

  return (
    <section>
      <div className="encabezado-pagina">
        <div>
          <h1>Panel de estadísticas</h1>
          <p className="subtitulo">Un resumen de las salidas y reservas registradas.</p>
        </div>
      </div>

      {estado === 'cargando' && <Cargando mensaje="Calculando estadísticas…" />}
      {estado === 'error' && <ErrorConexion mensaje={error} onReintentar={() => setRecarga((n) => n + 1)} />}
      {estado === 'ok' && datos && (
        <>
          <div className="panel-totales">
            <div className="panel-total">
              <strong>{datos.totalSalidas}</strong>
              <span>Salidas</span>
            </div>
            <div className="panel-total">
              <strong>{datos.totalEmpresas}</strong>
              <span>Empresas</span>
            </div>
            <div className="panel-total">
              <strong>{datos.cuposReservados}</strong>
              <span>Cupos reservados</span>
            </div>
            <div className="panel-total">
              <strong>{formatPrecio(datos.precioPromedio)}</strong>
              <span>Precio promedio</span>
            </div>
          </div>

          <div className="panel-graficos">
            <Grafico titulo="Salidas por destino" datos={datos.porDestino} clave="total" color={color} />
            <Grafico
              titulo="Precio promedio por destino (S/)"
              datos={datos.porDestino}
              clave="precioPromedio"
              color={colorPrecio}
              formato={formatPrecio}
            />
          </div>

          <div className="panel-listas">
            <div>
              <h2>Por tipo de embarcación</h2>
              <ul className="lista-simple">
                {datos.porTipo.map((t) => (
                  <li key={t.tipo}>
                    <span>{etiquetaTipo(t.tipo)}</span>
                    <strong>{t.total}</strong>
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <h2>Por estado</h2>
              <ul className="lista-simple">
                {datos.porEstado.map((t) => (
                  <li key={t.estado}>
                    <span>{etiquetaEstado(t.estado)}</span>
                    <strong>{t.total}</strong>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </>
      )}
    </section>
  );
}
