import { useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import ConfirmModal from '../components/ConfirmModal.jsx';
import { Cargando } from '../components/Estados.jsx';
import EstadoBadge from '../components/EstadoBadge.jsx';
import { useToast } from '../context/ToastContext.jsx';
import { cancelarReserva, consultarReserva } from '../services/api.js';
import { etiquetaTipo, formatFecha, formatHora, formatPrecio } from '../utils/format.js';

export default function ConsultaReserva() {
  const { codigo } = useParams();
  const navigate = useNavigate();
  const toast = useToast();

  const [texto, setTexto] = useState(codigo ?? '');
  const [reserva, setReserva] = useState(null);
  const [cargando, setCargando] = useState(false);
  const [error, setError] = useState('');
  const [confirmar, setConfirmar] = useState(false);
  const [cancelando, setCancelando] = useState(false);

  useEffect(() => {
    setTexto(codigo ?? '');
    setReserva(null);
    setError('');
    if (!codigo) return undefined;
    let vigente = true;
    setCargando(true);
    consultarReserva(codigo)
      .then((r) => vigente && setReserva(r))
      .catch((e) => vigente && setError(e.message))
      .finally(() => vigente && setCargando(false));
    return () => {
      vigente = false;
    };
  }, [codigo]);

  const buscar = (e) => {
    e.preventDefault();
    const limpio = texto.trim().toUpperCase();
    if (limpio) navigate(`/reserva/${encodeURIComponent(limpio)}`);
  };

  const cancelar = async () => {
    setCancelando(true);
    try {
      await cancelarReserva(reserva.id);
      toast.exito('Reserva cancelada. Tus cupos volvieron a la salida.');
      setConfirmar(false);
      setReserva(null);
      setError('Esta reserva fue cancelada.');
    } catch (e) {
      toast.error(e.message);
    } finally {
      setCancelando(false);
    }
  };

  const s = reserva?.salida;

  return (
    <section className="pagina-estrecha">
      <h1>Mi reserva</h1>
      <form className="formulario formulario-linea" onSubmit={buscar}>
        <label className="campo">
          <span>Código de reserva</span>
          <input
            type="text"
            placeholder="Ej.: LY-4F7K2"
            value={texto}
            onChange={(e) => setTexto(e.target.value)}
            autoCapitalize="characters"
          />
        </label>
        <button type="submit" className="btn">
          Consultar
        </button>
      </form>

      {cargando && <Cargando mensaje="Buscando tu reserva…" />}
      {error && !cargando && (
        <div className="aviso aviso-error" role="alert">
          {error}
        </div>
      )}

      {reserva && s && (
        <article className="detalle">
          <header className="detalle-cabecera">
            <div>
              <p className="reserva-codigo">{reserva.codigo}</p>
              <p className="tarjeta-empresa">A nombre de {reserva.nombre}</p>
            </div>
            <EstadoBadge estado={s.estado} />
          </header>
          <dl className="tarjeta-datos detalle-datos">
            <div>
              <dt>Destino</dt>
              <dd>{s.destino}</dd>
            </div>
            <div>
              <dt>Salida</dt>
              <dd>
                {formatFecha(s.fechaHora)} · {formatHora(s.fechaHora)}
              </dd>
            </div>
            <div>
              <dt>Puerto</dt>
              <dd>{s.puerto}</dd>
            </div>
            <div>
              <dt>Embarcación</dt>
              <dd>
                {s.empresa} · {etiquetaTipo(s.tipo)}
              </dd>
            </div>
            <div>
              <dt>Pasajes</dt>
              <dd>{reserva.cantidad}</dd>
            </div>
            <div>
              <dt>Total a pagar en puerto</dt>
              <dd className="precio">{formatPrecio(reserva.total)}</dd>
            </div>
          </dl>
          <div className="detalle-acciones">
            <Link className="btn btn-secundario" to={`/salidas/${s.id}`}>
              Ver la salida
            </Link>
            <button type="button" className="btn btn-peligro-suave" onClick={() => setConfirmar(true)}>
              Cancelar reserva
            </button>
          </div>
        </article>
      )}

      <ConfirmModal
        abierto={confirmar}
        titulo="¿Cancelar tu reserva?"
        mensaje="Tus cupos volverán a estar disponibles para otros pasajeros."
        textoConfirmar="Sí, cancelar reserva"
        ocupado={cancelando}
        onConfirmar={cancelar}
        onCancelar={() => !cancelando && setConfirmar(false)}
      />
    </section>
  );
}
