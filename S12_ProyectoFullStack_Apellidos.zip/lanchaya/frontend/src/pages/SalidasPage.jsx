import { useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import ConfirmModal from '../components/ConfirmModal.jsx';
import { Cargando, ErrorConexion, Vacio } from '../components/Estados.jsx';
import Filtros, { FILTROS_INICIALES } from '../components/Filtros.jsx';
import Paginacion from '../components/Paginacion.jsx';
import SalidaCard from '../components/SalidaCard.jsx';
import { useToast } from '../context/ToastContext.jsx';
import useDebounced from '../hooks/useDebounced.js';
import useLocalStorage from '../hooks/useLocalStorage.js';
import { eliminarSalida, listarDestinos, listarSalidas } from '../services/api.js';

const POR_PAGINA = 6;

function aParametros(filtros, page) {
  const { ventana, ...resto } = filtros;
  return {
    ...resto,
    hoy: ventana === 'hoy' ? 'true' : '',
    proximas48: ventana === '48h' ? 'true' : '',
    page,
    limit: POR_PAGINA,
  };
}

export default function SalidasPage() {
  const toast = useToast();
  // Los últimos filtros usados se guardan en localStorage
  const [filtros, setFiltros] = useLocalStorage('lanchaya.filtros', FILTROS_INICIALES);
  const [page, setPage] = useState(1);
  const [destinos, setDestinos] = useState([]);
  const [resultado, setResultado] = useState({ items: [], total: 0, totalPaginas: 1 });
  const [estado, setEstado] = useState('cargando'); // cargando | ok | error
  const [error, setError] = useState('');
  const [recarga, setRecarga] = useState(0);
  const [aEliminar, setAEliminar] = useState(null);
  const [eliminando, setEliminando] = useState(false);

  const filtrosRetrasados = useDebounced(filtros, 350);

  useEffect(() => {
    listarDestinos()
      .then(setDestinos)
      .catch(() => setDestinos([]));
  }, [recarga]);

  useEffect(() => {
    let vigente = true;
    setEstado('cargando');
    listarSalidas(aParametros(filtrosRetrasados, page))
      .then((r) => {
        if (!vigente) return;
        if (r.items.length === 0 && page > 1) {
          setPage(Math.max(1, r.totalPaginas));
          return;
        }
        setResultado(r);
        setEstado('ok');
      })
      .catch((e) => {
        if (!vigente) return;
        setError(e.message);
        setEstado('error');
      });
    return () => {
      vigente = false;
    };
  }, [filtrosRetrasados, page, recarga]);

  const cambiarFiltros = (nuevos) => {
    setFiltros(nuevos);
    setPage(1);
  };
  const limpiar = () => cambiarFiltros(FILTROS_INICIALES);
  const hayFiltros = JSON.stringify(filtros) !== JSON.stringify(FILTROS_INICIALES);

  const confirmarEliminar = useCallback(async () => {
    setEliminando(true);
    try {
      await eliminarSalida(aEliminar.id);
      toast.exito('Salida eliminada');
      setAEliminar(null);
      setRecarga((n) => n + 1);
    } catch (e) {
      toast.error(e.message);
    } finally {
      setEliminando(false);
    }
  }, [aEliminar, toast]);

  return (
    <section>
      <div className="encabezado-pagina">
        <div>
          <h1>Salidas desde Iquitos</h1>
          <p className="subtitulo">Lanchas, rápidos y deslizadores: horarios, puertos y precios en un solo lugar.</p>
        </div>
        <Link className="btn" to="/salidas/nueva">
          + Registrar salida
        </Link>
      </div>

      <Filtros filtros={filtros} destinos={destinos} onChange={cambiarFiltros} onLimpiar={limpiar} />

      {estado === 'cargando' && <Cargando mensaje="Buscando salidas…" />}
      {estado === 'error' && <ErrorConexion mensaje={error} onReintentar={() => setRecarga((n) => n + 1)} />}
      {estado === 'ok' && resultado.items.length === 0 && (
        <Vacio
          titulo="No hay salidas con esos filtros"
          mensaje={hayFiltros ? 'Prueba con otro destino o fecha, o limpia los filtros.' : 'Aún no hay salidas registradas.'}
        >
          {hayFiltros && (
            <button type="button" className="btn btn-secundario" onClick={limpiar}>
              Limpiar filtros
            </button>
          )}
        </Vacio>
      )}
      {estado === 'ok' && resultado.items.length > 0 && (
        <>
          <div className="rejilla-tarjetas">
            {resultado.items.map((s) => (
              <SalidaCard key={s.id} salida={s} onEliminar={setAEliminar} />
            ))}
          </div>
          <Paginacion page={page} totalPaginas={resultado.totalPaginas} total={resultado.total} onCambiar={setPage} />
        </>
      )}

      <ConfirmModal
        abierto={!!aEliminar}
        titulo="¿Eliminar esta salida?"
        mensaje={
          aEliminar
            ? `Se eliminará la salida a ${aEliminar.destino} de ${aEliminar.empresa} y sus reservas. Esta acción no se puede deshacer.`
            : ''
        }
        textoConfirmar="Sí, eliminar"
        ocupado={eliminando}
        onConfirmar={confirmarEliminar}
        onCancelar={() => !eliminando && setAEliminar(null)}
      />
    </section>
  );
}
