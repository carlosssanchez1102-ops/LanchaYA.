import { useCallback, useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import ConfirmModal from '../components/ConfirmModal.jsx';
import Countdown from '../components/Countdown.jsx';
import CuposBar from '../components/CuposBar.jsx';
import { Cargando, ErrorConexion } from '../components/Estados.jsx';
import EstadoBadge from '../components/EstadoBadge.jsx';
import ReservaForm from '../components/ReservaForm.jsx';
import { useToast } from '../context/ToastContext.jsx';
import { cambiarEstado, eliminarSalida, obtenerSalida } from '../services/api.js';
import {
  ESTADOS,
  etiquetaTipo,
  formatDuracion,
  formatFecha,
  formatHora,
  formatPrecio,
  mensajeWhatsApp,
} from '../utils/format.js';

export default function SalidaDetalle() {
  const { id } = useParams();
  const navigate = useNavigate();
  const toast = useToast();

  const [salida, setSalida] = useState(null);
  const [estado, setEstado] = useState('cargando');
  const [error, setError] = useState('');
  const [noExiste, setNoExiste] = useState(false);
  const [recarga, setRecarga] = useState(0);
  const [reservaHecha, setReservaHecha] = useState(null);
  const [confirmarEliminar, setConfirmarEliminar] = useState(false);
  const [eliminando, setEliminando] = useState(false);

  useEffect(() => {
    let vigente = true;
    // Al recargar tras una reserva no se vuelve a mostrar "cargando" para no perder la pantalla
    setEstado((previo) => (previo === 'ok' ? 'ok' : 'cargando'));
    obtenerSalida(id)
      .then((s) => {
        if (!vigente) return;
        setSalida(s);
        setNoExiste(false);
        setEstado('ok');
      })
      .catch((e) => {
        if (!vigente) return;
        setNoExiste(e.status === 404);
        setError(e.message);
        setEstado('error');
      });
    return () => {
      vigente = false;
    };
  }, [id, recarga]);

  const alCambiarEstado = async (e) => {
    try {
      const actualizada = await cambiarEstado(id, e.target.value);
      setSalida(actualizada);
      toast.exito('Estado actualizado');
    } catch (err) {
      toast.error(err.message);
    }
  };

  const eliminar = useCallback(async () => {
    setEliminando(true);
    try {
      await eliminarSalida(id);
      toast.exito('Salida eliminada');
      navigate('/');
    } catch (e) {
      toast.error(e.message);
      setEliminando(false);
    }
  }, [id, navigate, toast]);

  if (estado === 'cargando') return <Cargando />;
  if (estado === 'error') {
    return (
      <section className="pagina-estrecha">
        <ErrorConexion mensaje={error} onReintentar={noExiste ? undefined : () => setRecarga((n) => n + 1)} />
        <p className="migas">
          <Link to="/">← Volver a las salidas</Link>
        </p>
      </section>
    );
  }

  const aceptaReservas = (salida.estado === 'programada' || salida.estado === 'abordando') && salida.cupos > 0;
  let motivo = '';
  if (salida.estado === 'zarpó' || salida.estado === 'cancelada') motivo = `Esta salida está ${salida.estado} y ya no acepta reservas.`;
  else if (salida.cupos === 0) motivo = 'No quedan cupos disponibles.';

  return (
    <section className="pagina-estrecha">
      <p className="migas">
        <Link to="/">← Volver a las salidas</Link>
      </p>

      <article className="detalle">
        <header className="detalle-cabecera">
          <div>
            <h1>{salida.destino}</h1>
            <p className="tarjeta-empresa">
              {salida.empresa} · {etiquetaTipo(salida.tipo)}
              {salida.embarcacion ? ` “${salida.embarcacion}”` : ''}
            </p>
          </div>
          <EstadoBadge estado={salida.estado} />
        </header>

        <Countdown fechaHora={salida.fechaHora} />

        <dl className="tarjeta-datos detalle-datos">
          <div>
            <dt>Fecha</dt>
            <dd>{formatFecha(salida.fechaHora)}</dd>
          </div>
          <div>
            <dt>Hora</dt>
            <dd>{formatHora(salida.fechaHora)}</dd>
          </div>
          <div>
            <dt>Puerto</dt>
            <dd>{salida.puerto}</dd>
          </div>
          <div>
            <dt>Duración</dt>
            <dd>{formatDuracion(salida.duracionHoras)}</dd>
          </div>
          <div>
            <dt>Pasaje</dt>
            <dd className="precio">{formatPrecio(salida.precio)}</dd>
          </div>
        </dl>

        <CuposBar salida={salida} />

        <div className="detalle-acciones">
          <a className="btn btn-whatsapp" href={mensajeWhatsApp(salida)} target="_blank" rel="noopener noreferrer">
            Compartir por WhatsApp
          </a>
          <Link className="btn btn-secundario" to={`/salidas/${salida.id}/editar`}>
            Editar
          </Link>
          <button type="button" className="btn btn-peligro-suave" onClick={() => setConfirmarEliminar(true)}>
            Eliminar
          </button>
        </div>

        <label className="campo campo-estado">
          <span>Estado de la salida (para la empresa)</span>
          <select value={salida.estado} onChange={alCambiarEstado}>
            {ESTADOS.map((e) => (
              <option key={e.valor} value={e.valor}>
                {e.etiqueta}
              </option>
            ))}
          </select>
        </label>
      </article>

      {reservaHecha && (
        <div className="reserva-ok" role="status">
          <p>¡Reserva confirmada!</p>
          <p className="reserva-codigo">{reservaHecha.codigo}</p>
          <p>
            Guarda este código. Con él puedes consultar o cancelar tu reserva en{' '}
            <Link to={`/reserva/${reservaHecha.codigo}`}>Mi reserva</Link>.
          </p>
        </div>
      )}

      {aceptaReservas ? (
        <ReservaForm
          salida={salida}
          onReservado={(reserva) => {
            setReservaHecha(reserva);
            setRecarga((n) => n + 1);
          }}
        />
      ) : (
        <div className="aviso">{motivo}</div>
      )}

      <ConfirmModal
        abierto={confirmarEliminar}
        titulo="¿Eliminar esta salida?"
        mensaje="Se eliminará la salida y todas sus reservas. Esta acción no se puede deshacer."
        textoConfirmar="Sí, eliminar"
        ocupado={eliminando}
        onConfirmar={eliminar}
        onCancelar={() => !eliminando && setConfirmarEliminar(false)}
      />
    </section>
  );
}
