import { useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { Cargando, ErrorConexion, Vacio } from '../components/Estados.jsx';
import SalidaForm from '../components/SalidaForm.jsx';
import { useToast } from '../context/ToastContext.jsx';
import { actualizarSalida, crearSalida, listarDestinos, listarEmpresas, obtenerSalida } from '../services/api.js';

export default function SalidaFormPage() {
  const { id } = useParams();
  const editando = !!id;
  const navigate = useNavigate();
  const toast = useToast();

  const [estado, setEstado] = useState('cargando');
  const [error, setError] = useState('');
  const [empresas, setEmpresas] = useState([]);
  const [destinos, setDestinos] = useState([]);
  const [salida, setSalida] = useState(null);
  const [enviando, setEnviando] = useState(false);
  const [errorServidor, setErrorServidor] = useState('');
  const [recarga, setRecarga] = useState(0);

  useEffect(() => {
    let vigente = true;
    setEstado('cargando');
    Promise.all([listarEmpresas(), listarDestinos(), editando ? obtenerSalida(id) : Promise.resolve(null)])
      .then(([emp, dest, sal]) => {
        if (!vigente) return;
        setEmpresas(emp);
        setDestinos(dest);
        setSalida(sal);
        setEstado('ok');
      })
      .catch((e) => {
        if (!vigente) return;
        setError(e.message);
        setEstado('error');
      });
    return () => {
      vigente = false;
    };
  }, [id, editando, recarga]);

  const guardar = async (datos) => {
    setEnviando(true);
    setErrorServidor('');
    try {
      const guardada = editando ? await actualizarSalida(id, datos) : await crearSalida(datos);
      toast.exito(editando ? 'Salida actualizada' : 'Salida registrada');
      navigate(`/salidas/${guardada.id}`);
    } catch (e) {
      setErrorServidor(e.message);
      toast.error(e.message);
    } finally {
      setEnviando(false);
    }
  };

  return (
    <section className="pagina-estrecha">
      <p className="migas">
        <Link to="/">← Volver a las salidas</Link>
      </p>
      <h1>{editando ? 'Editar salida' : 'Registrar salida'}</h1>

      {estado === 'cargando' && <Cargando />}
      {estado === 'error' && <ErrorConexion mensaje={error} onReintentar={() => setRecarga((n) => n + 1)} />}
      {estado === 'ok' && empresas.length === 0 && (
        <Vacio titulo="Primero registra una empresa" mensaje="Cada salida pertenece a una empresa fluvial.">
          <Link className="btn" to="/empresas">
            Ir a Empresas
          </Link>
        </Vacio>
      )}
      {estado === 'ok' && empresas.length > 0 && (
        <SalidaForm
          salida={salida}
          empresas={empresas}
          destinos={destinos}
          enviando={enviando}
          errorServidor={errorServidor}
          onGuardar={guardar}
        />
      )}
    </section>
  );
}
