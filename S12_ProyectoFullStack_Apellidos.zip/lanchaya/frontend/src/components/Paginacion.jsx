export default function Paginacion({ page, totalPaginas, total, onCambiar }) {
  if (total === 0) return null;
  return (
    <nav className="paginacion" aria-label="Paginación">
      <button type="button" className="btn btn-secundario" disabled={page <= 1} onClick={() => onCambiar(page - 1)}>
        ← Anterior
      </button>
      <span>
        Página {page} de {totalPaginas} · {total} salida{total === 1 ? '' : 's'}
      </span>
      <button
        type="button"
        className="btn btn-secundario"
        disabled={page >= totalPaginas}
        onClick={() => onCambiar(page + 1)}
      >
        Siguiente →
      </button>
    </nav>
  );
}
