import { etiquetaEstado } from '../utils/format.js';

const CLASES = { programada: 'programada', abordando: 'abordando', zarpó: 'zarpo', cancelada: 'cancelada' };

export default function EstadoBadge({ estado }) {
  return <span className={`badge badge-${CLASES[estado] ?? 'programada'}`}>{etiquetaEstado(estado)}</span>;
}
