import { TIPOS } from '../utils/format.js';

export const FILTROS_INICIALES = {
  destino: '',
  fecha: '',
  tipo: '',
  q: '',
  precioMin: '',
  precioMax: '',
  ventana: '',
  orden: 'fecha',
  dir: 'asc',
};

export default function Filtros({ filtros, destinos, onChange, onLimpiar }) {
  const cambiar = (campo) => (e) => onChange({ ...filtros, [campo]: e.target.value });

  // "Solo hoy" y "Próximas 48 h" no se combinan con una fecha concreta
  const cambiarFecha = (e) => onChange({ ...filtros, fecha: e.target.value, ventana: e.target.value ? '' : filtros.ventana });
  const cambiarVentana = (e) => onChange({ ...filtros, ventana: e.target.value, fecha: e.target.value ? '' : filtros.fecha });

  return (
    <form className="filtros" onSubmit={(e) => e.preventDefault()} aria-label="Filtros de salidas">
      <label className="campo campo-ancho">
        <span>Buscar empresa o embarcación</span>
        <input type="search" placeholder="Ej.: Gilmer, Río Itaya" value={filtros.q} onChange={cambiar('q')} />
      </label>

      <label className="campo">
        <span>Destino</span>
        <select value={filtros.destino} onChange={cambiar('destino')}>
          <option value="">Todos</option>
          {destinos.map((d) => (
            <option key={d} value={d}>
              {d}
            </option>
          ))}
        </select>
      </label>

      <label className="campo">
        <span>Fecha</span>
        <input type="date" value={filtros.fecha} onChange={cambiarFecha} />
      </label>

      <label className="campo">
        <span>Tipo</span>
        <select value={filtros.tipo} onChange={cambiar('tipo')}>
          <option value="">Todos</option>
          {TIPOS.map((t) => (
            <option key={t.valor} value={t.valor}>
              {t.etiqueta}
            </option>
          ))}
        </select>
      </label>

      <label className="campo">
        <span>Cuándo</span>
        <select value={filtros.ventana} onChange={cambiarVentana}>
          <option value="">Cualquier día</option>
          <option value="hoy">Solo salidas de hoy</option>
          <option value="48h">Próximas 48 horas</option>
        </select>
      </label>

      <label className="campo campo-corto">
        <span>Precio mín. (S/)</span>
        <input type="number" min="0" inputMode="decimal" value={filtros.precioMin} onChange={cambiar('precioMin')} />
      </label>

      <label className="campo campo-corto">
        <span>Precio máx. (S/)</span>
        <input type="number" min="0" inputMode="decimal" value={filtros.precioMax} onChange={cambiar('precioMax')} />
      </label>

      <label className="campo">
        <span>Ordenar por</span>
        <select value={filtros.orden} onChange={cambiar('orden')}>
          <option value="fecha">Fecha</option>
          <option value="precio">Precio</option>
          <option value="duracion">Duración</option>
        </select>
      </label>

      <label className="campo campo-corto">
        <span>Sentido</span>
        <select value={filtros.dir} onChange={cambiar('dir')}>
          <option value="asc">Ascendente</option>
          <option value="desc">Descendente</option>
        </select>
      </label>

      <div className="campo campo-boton">
        <button type="button" className="btn btn-secundario" onClick={onLimpiar}>
          Limpiar filtros
        </button>
      </div>
    </form>
  );
}
