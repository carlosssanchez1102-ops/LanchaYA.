import { useEffect } from 'react';

export default function ConfirmModal({
  abierto,
  titulo,
  mensaje,
  textoConfirmar = 'Confirmar',
  textoCancelar = 'Volver',
  ocupado = false,
  onConfirmar,
  onCancelar,
}) {
  useEffect(() => {
    if (!abierto) return undefined;
    const alTeclear = (e) => e.key === 'Escape' && onCancelar();
    window.addEventListener('keydown', alTeclear);
    return () => window.removeEventListener('keydown', alTeclear);
  }, [abierto, onCancelar]);

  if (!abierto) return null;

  return (
    <div className="modal-fondo" onClick={onCancelar}>
      <div
        className="modal"
        role="dialog"
        aria-modal="true"
        aria-labelledby="modal-titulo"
        onClick={(e) => e.stopPropagation()}
      >
        <h2 id="modal-titulo">{titulo}</h2>
        <p>{mensaje}</p>
        <div className="modal-acciones">
          <button type="button" className="btn btn-secundario" onClick={onCancelar} disabled={ocupado}>
            {textoCancelar}
          </button>
          <button type="button" className="btn btn-peligro" onClick={onConfirmar} disabled={ocupado} autoFocus>
            {ocupado ? 'Procesando…' : textoConfirmar}
          </button>
        </div>
      </div>
    </div>
  );
}
