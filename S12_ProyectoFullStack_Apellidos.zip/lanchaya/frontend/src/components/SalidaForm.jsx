import { useState } from 'react';
import { Link } from 'react-router-dom';
import Campo from './Campo.jsx';
import { PUERTOS, TIPOS, ahoraLima } from '../utils/format.js';
import { validarSalida } from '../utils/validar.js';

const VACIO = {
  empresaId: '',
  embarcacion: '',
  tipo: '',
  destino: '',
  puerto: '',
  fechaHora: '',
  duracionHoras: '',
  precio: '',
  capacidad: '',
};

function desdeSalida(s) {
  return {
    empresaId: s.empresaId ? String(s.empresaId) : '',
    embarcacion: s.embarcacion ?? '',
    tipo: s.tipo,
    destino: s.destino,
    puerto: s.puerto,
    fechaHora: s.fechaHora.slice(0, 16),
    duracionHoras: String(s.duracionHoras),
    precio: String(s.precio),
    capacidad: String(s.capacidad),
  };
}

export default function SalidaForm({ salida, empresas, destinos, enviando, errorServidor, onGuardar }) {
  const [form, setForm] = useState(salida ? desdeSalida(salida) : VACIO);
  const [errores, setErrores] = useState({});
  const reservados = salida ? salida.capacidad - salida.cupos : 0;

  const cambiar = (campo) => (e) => {
    setForm((f) => ({ ...f, [campo]: e.target.value }));
    if (errores[campo]) setErrores((er) => ({ ...er, [campo]: undefined }));
  };

  // Al elegir empresa en una salida nueva, sugiere su puerto base
  const cambiarEmpresa = (e) => {
    const id = e.target.value;
    const empresa = empresas.find((x) => String(x.id) === id);
    setForm((f) => ({ ...f, empresaId: id, puerto: f.puerto || empresa?.puertoBase || '' }));
    if (errores.empresaId) setErrores((er) => ({ ...er, empresaId: undefined }));
  };

  const enviar = (e) => {
    e.preventDefault();
    const nuevos = validarSalida(form, { original: salida, reservados });
    setErrores(nuevos);
    if (Object.keys(nuevos).length) return;
    onGuardar({
      empresaId: Number(form.empresaId),
      embarcacion: form.embarcacion.trim(),
      tipo: form.tipo,
      destino: form.destino.trim(),
      puerto: form.puerto.trim(),
      fechaHora: form.fechaHora,
      duracionHoras: Number(form.duracionHoras),
      precio: Number(form.precio),
      capacidad: Number(form.capacidad),
    });
  };

  return (
    <form className="formulario" onSubmit={enviar} noValidate>
      {errorServidor && (
        <div className="aviso aviso-error" role="alert">
          {errorServidor}
        </div>
      )}

      <div className="formulario-rejilla">
        <Campo etiqueta="Empresa *" error={errores.empresaId}>
          <select value={form.empresaId} onChange={cambiarEmpresa}>
            <option value="">Selecciona una empresa</option>
            {empresas.map((e) => (
              <option key={e.id} value={e.id}>
                {e.razonSocial}
              </option>
            ))}
          </select>
        </Campo>

        <Campo etiqueta="Embarcación" error={errores.embarcacion}>
          <input type="text" value={form.embarcacion} onChange={cambiar('embarcacion')} placeholder="Ej.: Don José II" />
        </Campo>

        <Campo etiqueta="Tipo *" error={errores.tipo}>
          <select value={form.tipo} onChange={cambiar('tipo')}>
            <option value="">Selecciona el tipo</option>
            {TIPOS.map((t) => (
              <option key={t.valor} value={t.valor}>
                {t.etiqueta}
              </option>
            ))}
          </select>
        </Campo>

        <Campo etiqueta="Destino *" error={errores.destino}>
          <input type="text" list="lista-destinos" value={form.destino} onChange={cambiar('destino')} placeholder="Ej.: Nauta" />
          <datalist id="lista-destinos">
            {destinos.map((d) => (
              <option key={d} value={d} />
            ))}
          </datalist>
        </Campo>

        <Campo etiqueta="Puerto de salida *" error={errores.puerto}>
          <input type="text" list="lista-puertos" value={form.puerto} onChange={cambiar('puerto')} placeholder="Ej.: Puerto Henry" />
          <datalist id="lista-puertos">
            {PUERTOS.map((p) => (
              <option key={p} value={p} />
            ))}
          </datalist>
        </Campo>

        <Campo etiqueta="Fecha y hora de salida *" error={errores.fechaHora} ayuda="Hora de Iquitos">
          <input
            type="datetime-local"
            value={form.fechaHora}
            min={salida ? undefined : ahoraLima()}
            onChange={cambiar('fechaHora')}
          />
        </Campo>

        <Campo etiqueta="Duración (horas) *" error={errores.duracionHoras}>
          <input type="number" min="0" step="0.5" inputMode="decimal" value={form.duracionHoras} onChange={cambiar('duracionHoras')} />
        </Campo>

        <Campo etiqueta="Precio del pasaje (S/) *" error={errores.precio}>
          <input type="number" min="0" step="0.5" inputMode="decimal" value={form.precio} onChange={cambiar('precio')} />
        </Campo>

        <Campo
          etiqueta="Cupos totales *"
          error={errores.capacidad}
          ayuda={reservados ? `Ya hay ${reservados} cupos reservados` : undefined}
        >
          <input type="number" min={Math.max(1, reservados)} step="1" inputMode="numeric" value={form.capacidad} onChange={cambiar('capacidad')} />
        </Campo>
      </div>

      <div className="formulario-acciones">
        <Link className="btn btn-secundario" to={salida ? `/salidas/${salida.id}` : '/'}>
          Cancelar
        </Link>
        <button type="submit" className="btn" disabled={enviando}>
          {enviando ? 'Guardando…' : salida ? 'Guardar cambios' : 'Registrar salida'}
        </button>
      </div>
    </form>
  );
}
