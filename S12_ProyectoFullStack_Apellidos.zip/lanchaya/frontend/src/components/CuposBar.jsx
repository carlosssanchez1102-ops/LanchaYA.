import { colorCupos, porcentajeCupos } from '../utils/format.js';

// Barra de cupos: verde > 50 % libres, amarillo 20-50 %, rojo < 20 %
export default function CuposBar({ salida }) {
  const color = colorCupos(salida);
  const libres = porcentajeCupos(salida);
  const ocupados = salida.capacidad - salida.cupos;
  return (
    <div className="cupos">
      <div
        className="cupos-barra"
        role="progressbar"
        aria-valuemin={0}
        aria-valuemax={salida.capacidad}
        aria-valuenow={ocupados}
        aria-label="Cupos ocupados"
      >
        <div className={`cupos-relleno cupos-${color}`} style={{ width: `${100 - libres}%` }} />
      </div>
      <p className="cupos-texto">
        {salida.cupos === 0 ? 'Sin cupos' : `${salida.cupos} de ${salida.capacidad} cupos disponibles`}
      </p>
    </div>
  );
}
