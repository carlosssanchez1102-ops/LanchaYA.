export function Cargando({ mensaje = 'Cargando…' }) {
  return (
    <div className="estado-caja" role="status">
      <span className="spinner" aria-hidden="true" />
      <p>{mensaje}</p>
    </div>
  );
}

export function Vacio({ titulo = 'No hay resultados', mensaje, children }) {
  return (
    <div className="estado-caja">
      <p className="estado-titulo">{titulo}</p>
      {mensaje && <p>{mensaje}</p>}
      {children}
    </div>
  );
}

export function ErrorConexion({ mensaje, onReintentar }) {
  return (
    <div className="estado-caja estado-error" role="alert">
      <p className="estado-titulo">Algo salió mal</p>
      <p>{mensaje}</p>
      {onReintentar && (
        <button type="button" className="btn" onClick={onReintentar}>
          Reintentar
        </button>
      )}
    </div>
  );
}
