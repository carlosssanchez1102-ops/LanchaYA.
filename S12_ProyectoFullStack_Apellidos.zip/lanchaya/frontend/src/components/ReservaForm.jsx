import { useState } from 'react';
import Campo from './Campo.jsx';
import { crearReserva } from '../services/api.js';
import { useToast } from '../context/ToastContext.jsx';
import { validarReserva } from '../utils/validar.js';

const VACIO = { nombre: '', dni: '', telefono: '', cantidad: '1' };

export default function ReservaForm({ salida, onReservado }) {
  const toast = useToast();
  const [form, setForm] = useState(VACIO);
  const [errores, setErrores] = useState({});
  const [enviando, setEnviando] = useState(false);

  const cambiar = (campo) => (e) => {
    setForm((f) => ({ ...f, [campo]: e.target.value }));
    if (errores[campo]) setErrores((er) => ({ ...er, [campo]: undefined }));
  };

  const enviar = async (e) => {
    e.preventDefault();
    const nuevos = validarReserva(form, salida.cupos);
    setErrores(nuevos);
    if (Object.keys(nuevos).length) return;

    setEnviando(true);
    try {
      const reserva = await crearReserva(salida.id, {
        nombre: form.nombre.trim(),
        dni: form.dni.trim(),
        telefono: form.telefono.trim(),
        cantidad: Number(form.cantidad),
      });
      toast.exito(`Reserva confirmada: ${reserva.codigo}`);
      setForm(VACIO);
      onReservado(reserva);
    } catch (err) {
      toast.error(err.message);
    } finally {
      setEnviando(false);
    }
  };

  return (
    <form className="formulario" onSubmit={enviar} noValidate>
      <h2>Reservar cupos</h2>
      <p className="ayuda">Sin pago: separas tu cupo y pagas en el puerto. Guarda tu código de reserva.</p>
      <div className="formulario-rejilla">
        <Campo etiqueta="Nombre completo *" error={errores.nombre}>
          <input type="text" autoComplete="name" value={form.nombre} onChange={cambiar('nombre')} />
        </Campo>
        <Campo etiqueta="DNI *" error={errores.dni}>
          <input type="text" inputMode="numeric" maxLength={8} autoComplete="off" value={form.dni} onChange={cambiar('dni')} />
        </Campo>
        <Campo etiqueta="Teléfono *" error={errores.telefono}>
          <input type="tel" autoComplete="tel" value={form.telefono} onChange={cambiar('telefono')} />
        </Campo>
        <Campo etiqueta="Cantidad de pasajes *" error={errores.cantidad}>
          <input type="number" min="1" max={salida.cupos} step="1" inputMode="numeric" value={form.cantidad} onChange={cambiar('cantidad')} />
        </Campo>
      </div>
      <div className="formulario-acciones">
        <button type="submit" className="btn" disabled={enviando}>
          {enviando ? 'Reservando…' : 'Confirmar reserva'}
        </button>
      </div>
    </form>
  );
}
