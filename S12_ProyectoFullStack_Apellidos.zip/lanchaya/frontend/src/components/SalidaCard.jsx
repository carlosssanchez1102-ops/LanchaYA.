import { Link } from 'react-router-dom';
import CuposBar from './CuposBar.jsx';
import EstadoBadge from './EstadoBadge.jsx';
import { etiquetaTipo, formatDuracion, formatFecha, formatHora, formatPrecio } from '../utils/format.js';

export default function SalidaCard({ salida, onEliminar }) {
  return (
    <article className="tarjeta">
      <header className="tarjeta-cabecera">
        <div>
          <h3 className="tarjeta-destino">{salida.destino}</h3>
          <p className="tarjeta-empresa">{salida.empresa}</p>
        </div>
        <EstadoBadge estado={salida.estado} />
      </header>

      <p className="tarjeta-hora">
        <strong>{formatHora(salida.fechaHora)}</strong>
        <span>{formatFecha(salida.fechaHora)}</span>
      </p>

      <dl className="tarjeta-datos">
        <div>
          <dt>Puerto</dt>
          <dd>{salida.puerto}</dd>
        </div>
        <div>
          <dt>Embarcación</dt>
          <dd>
            {etiquetaTipo(salida.tipo)}
            {salida.embarcacion ? ` · ${salida.embarcacion}` : ''}
          </dd>
        </div>
        <div>
          <dt>Duración</dt>
          <dd>{formatDuracion(salida.duracionHoras)}</dd>
        </div>
        <div>
          <dt>Pasaje</dt>
          <dd className="precio">{formatPrecio(salida.precio)}</dd>
        </div>
      </dl>

      <CuposBar salida={salida} />

      <footer className="tarjeta-acciones">
        <Link className="btn" to={`/salidas/${salida.id}`}>
          Ver detalle
        </Link>
        <Link className="btn btn-secundario" to={`/salidas/${salida.id}/editar`}>
          Editar
        </Link>
        <button type="button" className="btn btn-peligro-suave" onClick={() => onEliminar(salida)}>
          Eliminar
        </button>
      </footer>
    </article>
  );
}
