// Etiqueta + control + mensaje de error accesible
export default function Campo({ etiqueta, error, ayuda, children }) {
  return (
    <label className={`campo${error ? ' campo-error' : ''}`}>
      <span>{etiqueta}</span>
      {children}
      {ayuda && !error && <small className="ayuda">{ayuda}</small>}
      {error && (
        <small className="error-texto" role="alert">
          {error}
        </small>
      )}
    </label>
  );
}
