import { useEffect, useState } from 'react';
import { aDate } from '../utils/format.js';

function partes(ms) {
  const total = Math.floor(ms / 1000);
  return {
    d: Math.floor(total / 86400),
    h: Math.floor((total % 86400) / 3600),
    m: Math.floor((total % 3600) / 60),
    s: total % 60,
  };
}

export default function Countdown({ fechaHora }) {
  const [ahora, setAhora] = useState(Date.now());

  useEffect(() => {
    const t = setInterval(() => setAhora(Date.now()), 1000);
    return () => clearInterval(t);
  }, []);

  const falta = aDate(fechaHora).getTime() - ahora;
  if (!Number.isFinite(falta)) return null;
  if (falta <= 0) return <p className="countdown countdown-fin">La hora de salida ya pasó</p>;

  const { d, h, m, s } = partes(falta);
  const unidades = [
    [d, 'd'],
    [h, 'h'],
    [m, 'min'],
    [s, 's'],
  ];
  return (
    <div className="countdown" role="timer" aria-label="Tiempo restante para la salida">
      {unidades.map(([valor, etiqueta]) => (
        <div key={etiqueta} className="countdown-bloque">
          <strong>{String(valor).padStart(2, '0')}</strong>
          <span>{etiqueta}</span>
        </div>
      ))}
    </div>
  );
}
