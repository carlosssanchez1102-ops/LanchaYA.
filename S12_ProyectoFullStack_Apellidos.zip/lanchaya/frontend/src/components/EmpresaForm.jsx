import { useEffect, useState } from 'react';
import Campo from './Campo.jsx';
import { PUERTOS } from '../utils/format.js';
import { validarEmpresa } from '../utils/validar.js';

const VACIO = { razonSocial: '', ruc: '', telefono: '', puertoBase: '' };

export default function EmpresaForm({ empresa, enviando, errorServidor, onGuardar, onCancelar }) {
  const [form, setForm] = useState(VACIO);
  const [errores, setErrores] = useState({});

  useEffect(() => {
    setForm(empresa ? { ...VACIO, ...empresa } : VACIO);
    setErrores({});
  }, [empresa]);

  const cambiar = (campo) => (e) => {
    setForm((f) => ({ ...f, [campo]: e.target.value }));
    if (errores[campo]) setErrores((er) => ({ ...er, [campo]: undefined }));
  };

  const enviar = (e) => {
    e.preventDefault();
    const nuevos = validarEmpresa(form);
    setErrores(nuevos);
    if (Object.keys(nuevos).length) return;
    onGuardar({
      razonSocial: form.razonSocial.trim(),
      ruc: form.ruc.trim(),
      telefono: form.telefono.trim(),
      puertoBase: form.puertoBase.trim(),
    });
  };

  return (
    <form className="formulario" onSubmit={enviar} noValidate>
      <h2>{empresa ? 'Editar empresa' : 'Nueva empresa'}</h2>
      {errorServidor && (
        <div className="aviso aviso-error" role="alert">
          {errorServidor}
        </div>
      )}
      <Campo etiqueta="Razón social *" error={errores.razonSocial}>
        <input type="text" value={form.razonSocial} onChange={cambiar('razonSocial')} />
      </Campo>
      <Campo etiqueta="RUC (11 dígitos) *" error={errores.ruc}>
        <input type="text" inputMode="numeric" maxLength={11} value={form.ruc} onChange={cambiar('ruc')} />
      </Campo>
      <Campo etiqueta="Teléfono *" error={errores.telefono}>
        <input type="tel" value={form.telefono} onChange={cambiar('telefono')} />
      </Campo>
      <Campo etiqueta="Puerto base *" error={errores.puertoBase}>
        <input type="text" list="puertos-base" value={form.puertoBase} onChange={cambiar('puertoBase')} />
        <datalist id="puertos-base">
          {PUERTOS.map((p) => (
            <option key={p} value={p} />
          ))}
        </datalist>
      </Campo>
      <div className="formulario-acciones">
        {empresa && (
          <button type="button" className="btn btn-secundario" onClick={onCancelar}>
            Cancelar edición
          </button>
        )}
        <button type="submit" className="btn" disabled={enviando}>
          {enviando ? 'Guardando…' : empresa ? 'Guardar cambios' : 'Registrar empresa'}
        </button>
      </div>
    </form>
  );
}
