import { NavLink, Route, Routes, Link } from 'react-router-dom';
import { useTema } from './context/TemaContext.jsx';
import ConsultaReserva from './pages/ConsultaReserva.jsx';
import EmpresasPage from './pages/EmpresasPage.jsx';
import PanelPage from './pages/PanelPage.jsx';
import SalidaDetalle from './pages/SalidaDetalle.jsx';
import SalidaFormPage from './pages/SalidaFormPage.jsx';
import SalidasPage from './pages/SalidasPage.jsx';

function NoEncontrada() {
  return (
    <section className="pagina-estrecha">
      <div className="estado-caja">
        <p className="estado-titulo">Página no encontrada</p>
        <Link className="btn" to="/">
          Ir al inicio
        </Link>
      </div>
    </section>
  );
}

export default function App() {
  const { tema, alternar } = useTema();

  return (
    <div className="app">
      <header className="cabecera">
        <div className="cabecera-interior">
          <Link to="/" className="logo">
            Lancha<span>Ya</span>
          </Link>
          <nav className="menu" aria-label="Principal">
            <NavLink to="/" end>
              Salidas
            </NavLink>
            <NavLink to="/empresas">Empresas</NavLink>
            <NavLink to="/panel">Panel</NavLink>
            <NavLink to="/reserva">Mi reserva</NavLink>
          </nav>
          <button
            type="button"
            className="btn-tema"
            onClick={alternar}
            aria-label={tema === 'oscuro' ? 'Cambiar a modo claro' : 'Cambiar a modo oscuro'}
            title={tema === 'oscuro' ? 'Modo claro' : 'Modo oscuro'}
          >
            {tema === 'oscuro' ? '☀' : '☾'}
          </button>
        </div>
      </header>

      <main className="contenido">
        <Routes>
          <Route path="/" element={<SalidasPage />} />
          <Route path="/salidas/nueva" element={<SalidaFormPage />} />
          <Route path="/salidas/:id" element={<SalidaDetalle />} />
          <Route path="/salidas/:id/editar" element={<SalidaFormPage />} />
          <Route path="/empresas" element={<EmpresasPage />} />
          <Route path="/panel" element={<PanelPage />} />
          <Route path="/reserva" element={<ConsultaReserva />} />
          <Route path="/reserva/:codigo" element={<ConsultaReserva />} />
          <Route path="*" element={<NoEncontrada />} />
        </Routes>
      </main>

      <footer className="pie">LanchaYa Iquitos · Horarios y precios referenciales; confirma en el puerto.</footer>
    </div>
  );
}
